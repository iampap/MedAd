package com.example.medod_admin;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.HashMap;

public class myprofile extends AppCompatActivity {
    //binding
    EditText na,ph;
    TextView em;
    Button up;
    //string for set up in database
    private String imgurl;
    private String email , usname , mobno;
    //image
    private ImageView proimage;
    private static final int gallpic = 1;
    private Uri imguri;
    //firebase
    private DatabaseReference references;
    private StorageReference prostroref;
    FirebaseAuth mauth;
    FirebaseUser fuser;
    //alertdialoge
    private AlertDialog alertDialog;
    //Toast
    private Toast toast;
    //on start of activity load data
    public  void onStart(){
        super.onStart();
        references.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                references.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.child("Profile").exists())
                        {
                            String usname = dataSnapshot.child("Profile").child("UserName").getValue().toString();
                            String eml = dataSnapshot.child("Profile").child("UserEmail").getValue().toString();
                            String phno = dataSnapshot.child("Profile").child("PhoneNumber").getValue().toString();
                            na.setText(usname);
                            em.setText(eml);
                            ph.setText(phno);
                            if (dataSnapshot.child("Profile").child("image").exists()) {
                                String im = dataSnapshot.child("Profile").child("image").getValue().toString();
                                Picasso.get().load(im).into(proimage);
                            }
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(getApplicationContext(),databaseError.getMessage(),Toast.LENGTH_LONG).show();
                    }
                });
                //load image
                /*references.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.child("image").exists()) {
                            String im = dataSnapshot.child("image").getValue().toString();
                            Picasso.get().load(im).into(proimage);
                        }
                        else {
                            Toast.makeText(getApplicationContext(),"Plz Add Image!!",Toast.LENGTH_SHORT).show();
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(getApplicationContext(),databaseError.getMessage(),Toast.LENGTH_SHORT).show();
                    }
                });*/
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(),databaseError.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myprofile);
        //binding
        na =(EditText)findViewById(R.id.name);
        em = (TextView) findViewById(R.id.email);
        ph = (EditText)findViewById(R.id.phone);
        up = (Button)findViewById(R.id.update);
        proimage = (ImageView)findViewById(R.id.userimg);
        //firebase binding
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        references = FirebaseDatabase.getInstance().getReference().child("Admin").child(fuser.getUid());
        prostroref  = FirebaseStorage.getInstance().getReference().child("User Image").child(fuser.getUid());
        //on click
        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateuser();
            }
        });
        proimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenGallery();
            }
        });
    }
    //update data in user profile
    private void updateuser() {
        email = em.getText().toString().trim();
        usname = na.getText().toString().trim();
        mobno=ph.getText().toString().trim();
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        if (email.isEmpty()) {
            em.setError("Email please..");
            em.requestFocus();
            return;
        }
        if(imguri == null)
        {
            toast= Toast.makeText(getApplicationContext(),"Image Required",Toast.LENGTH_LONG);
            toast();
        }
        else if (!email.matches(emailPattern)) {
            em.setError("Invalid Email");
            em.requestFocus();
            return;
        }
        else if (usname.isEmpty()) {
            na.setError("Name please..");
            na.requestFocus();
            return;
        }
        else if (mobno.isEmpty()) {
            ph.setError("Mob No please..");
            ph.requestFocus();
            return;
        }
        else{
            storeitemsinformation();
        }
        //stroing the image from user
    }
    private void storeitemsinformation() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Updating (कृपया रुकिये)");
        dialog.setMessage("Hang On, Updating your Profile takes less than a minute!!");
        dialog.setCancelable(false);
        alertDialog = dialog.create();
        alertDialog.show();
        //upload image in database storage
        final StorageReference filepath = prostroref.child(imguri.getEncodedPath()+".jpg");
        final UploadTask uploadTask = filepath.putFile(imguri);
        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                String mess = e.toString();
                Toast.makeText(getApplicationContext(),"Error" + mess,Toast.LENGTH_SHORT);
                alertDialog.dismiss();
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Task<Uri> uriTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                    @Override
                    public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                        if(!task.isSuccessful())
                        {
                            throw task.getException();
                        }
                        //taking the image url to set in the database
                        imgurl = filepath.getDownloadUrl().toString();
                        return filepath.getDownloadUrl();
                    }
                }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                    @Override
                    public void onComplete(@NonNull Task<Uri> task) {
                        if(task.isSuccessful())
                        {
                            imgurl = task.getResult().toString();
                            //call the func
                            saveproinfodatbase();
                        }
                    }
                });
            }
        });
    }
    //saving all the data in the user database
    private void saveproinfodatbase() {
        HashMap<String, String> map = new HashMap<>();
        map.put("UserName", usname);
        map.put("UserEmail", email);
        map.put("PhoneNumber", mobno);
        map.put("image",imgurl);
        map.put("userid",fuser.getUid());
        references.child("Profile").setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    alertDialog.dismiss();
                    toast=Toast.makeText(getApplicationContext(),"Update Successful!!",Toast.LENGTH_SHORT);
                    toast();
                }
                else
                {
                    alertDialog.dismiss();
                    Toast.makeText(getApplicationContext(),"Error>>"+task.getException().toString(),Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    //to take image from user
    private void OpenGallery()
    {
        Intent in = new Intent();
        in.setAction(Intent.ACTION_GET_CONTENT);
        in.setType("image/*");
        startActivityForResult(in,gallpic);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == gallpic && resultCode == RESULT_OK && data!=null)
        {
            imguri = data.getData();
            proimage.setImageURI(imguri);
        }
    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}