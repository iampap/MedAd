package com.example.medod_admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class login extends AppCompatActivity {
    //binding
    EditText edemail, edpass;
    //firebase
    private FirebaseAuth mAuth;
    private FirebaseUser firebaseUser;
    private DatabaseReference references;
    //alert
    private AlertDialog alertDialog;
    //Toast
    private Toast toast;
    @Override
    public void onStart() {
        super.onStart();
        if(firebaseUser != null){
            Intent in = new Intent(login.this, MainActivity.class);
            startActivity(in);
            finish();
        }
        references.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.child("Admin").exists())
                {
                }
                else{
                    Intent in = new Intent(login.this, Register.class);
                    startActivity(in);
                    finish();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(),databaseError.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        //binding
        edemail = (EditText) findViewById(R.id.loginemail);
        edpass = (EditText) findViewById(R.id.loginpass);
        //firebase binding
        mAuth = FirebaseAuth.getInstance();
        firebaseUser = mAuth.getCurrentUser();
        references = FirebaseDatabase.getInstance().getReference();
        //user login button
        final Button userbtnsignin = (Button) findViewById(R.id.loginbtn);
        userbtnsignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userlogin();
            }
        });
    }
    //user login validation
    private void userlogin() {
        final String email = edemail.getText().toString().trim();
        String password = edpass.getText().toString().trim();
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        if (email.isEmpty()) {
            edemail.setError("Email plz..");
            edemail.requestFocus();
            return;
        } else {
            if (!email.matches(emailPattern)) {
                edemail.setError("Invalid please");
                edemail.requestFocus();
                return;
            }
        }
        if (password.isEmpty()) {
            edpass.setError("Password please..");
            edpass.requestFocus();
            return;
        }
        if (password.length() < 4) {
            edpass.setError("More than 4");
            edpass.requestFocus();
            return;
        }
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Login");
        dialog.setMessage("Hang On!!");
        dialog.setCancelable(false);
        alertDialog = dialog.create();
        alertDialog.show();
        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                alertDialog.dismiss();
                if (task.isSuccessful()) {
                    Intent in = new Intent(login.this, MainActivity.class);
                    startActivity(in);
                    finish();
                } else {
                    Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}