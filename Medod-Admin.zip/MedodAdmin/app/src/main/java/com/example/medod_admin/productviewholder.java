package com.example.medod_admin;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class productviewholder extends RecyclerView.ViewHolder implements View.OnClickListener {
    TextView proname,procount;
    public itemclicklistner productdet;
    public productviewholder(@NonNull View itemView) {
        super(itemView);
        proname=itemView.findViewById(R.id.productname);
        procount=itemView.findViewById(R.id.productcount);
    }
    @Override
    public void onClick(View v) {
    }
    public void setProductdet(itemclicklistner productdet) {
        this.productdet = productdet;
    }
}