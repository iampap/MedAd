package com.example.medod_admin;

public class userorderlistdata {
    String orderstatus;
    public userorderlistdata() {
    }

    public userorderlistdata(String orderstatus) {
        this.orderstatus = orderstatus;
    }

    public String getOrderstatus() {
        return orderstatus;
    }

    public void setOrderstatus(String orderstatus) {
        this.orderstatus = orderstatus;
    }
}
