package com.example.medod_admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.List;

public class productlistdetails extends AppCompatActivity {
    private TextView date,time,category,img,id,itid,delete,upd;
    private EditText nam,dispri,desc,ogproprice,prooverview,prodingredients,prodosage,prolife,
            pronetquantity,probrandabout,procaution,proinfo,procertification;
    private String dt,tm,ct,im,pid,dispr,nm,des,ogpri,overview,inge,dosag,lfe,netqt,abtbrnd,caution,info,certifi;
    private ImageView image;
    //toast
    private Toast toast;
    //firebase
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    private DatabaseReference ref;
    //another database
    private FirebaseDatabase secondaryDatabase;
    private StorageReference storageReference;
    //alertdialoge
    private AlertDialog alertDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productlistdetails);
        //Binding
        itid=findViewById(R.id.itemid);
        date =findViewById(R.id.itdate);
        time=findViewById(R.id.ittime);
        category=findViewById(R.id.itcate);
        img=findViewById(R.id.itimg);
        image=findViewById(R.id.itimage);
        id=findViewById(R.id.itid);
        nam=findViewById(R.id.itname);
        dispri=findViewById(R.id.itdisprice);
        desc=findViewById(R.id.itdesc);
        delete=findViewById(R.id.delitem);
        upd=findViewById(R.id.updatebutton);
        ogproprice=findViewById(R.id.itogprice);
        prooverview=findViewById(R.id.itoverview);
        prodingredients=findViewById(R.id.itdingredients);
        prodosage=findViewById(R.id.itdosage);
        prolife=findViewById(R.id.itlife);
        pronetquantity=findViewById(R.id.itnetquantity);
        probrandabout=findViewById(R.id.itbrandabout);
        procaution=findViewById(R.id.itcaution);
        proinfo=findViewById(R.id.itinfo);
        procertification=findViewById(R.id.itcertification);
        //Getintent
        dt=getIntent().getStringExtra("date");
        tm=getIntent().getStringExtra("time");
        ct=getIntent().getStringExtra("category");
        im=getIntent().getStringExtra("image");
        pid=getIntent().getStringExtra("pid");
        dispr=getIntent().getStringExtra("disprice");
        nm=getIntent().getStringExtra("proname");
        des=getIntent().getStringExtra("description");
        ogpri=getIntent().getStringExtra("ogprice");
        overview=getIntent().getStringExtra("prooverview");
        inge=getIntent().getStringExtra("proingredients");
        dosag=getIntent().getStringExtra("prodosage");
        lfe=getIntent().getStringExtra("prolife");
        netqt=getIntent().getStringExtra("pronetquantity");
        abtbrnd=getIntent().getStringExtra("probrandabout");
        caution=getIntent().getStringExtra("procaution");
        info=getIntent().getStringExtra("proinfo");
        certifi=getIntent().getStringExtra("procertification");
        //settingimage and text
        date.setText("Item Added Date : "+dt.toString());
        time.setText("Item Added Time : "+tm.toString());
        category.setText("Item Category : "+ct.toString());
        img.setText("Item Image URL : "+im.toString());
        id.setText("Item ID : "+pid.toString());
        nam.setText(nm.toString());
        dispri.setText(dispr.toString());
        desc.setText(des.toString());
        itid.setText("Item ID : "+pid.toString());
        Picasso.get().load(im).into(image);
        ogproprice.setText(ogpri.toString());
        prooverview.setText(overview.toString());
        prodingredients.setText(inge.toString());
        prodosage.setText(dosag.toString());
        prolife.setText(lfe.toString());
        pronetquantity.setText(netqt.toString());
        probrandabout.setText(abtbrnd.toString());
        procaution.setText(caution.toString());
        proinfo.setText(info.toString());
        procertification.setText(certifi.toString());
        //firebase
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        //getting details from another database
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setProjectId("medodd-d2fcc")
                .setApplicationId("1:468581190085:android:f71679ff61d4ba646c63ac")
                .setDatabaseUrl("https://medodd-d2fcc.firebaseio.com")
                .setApiKey("AIzaSyAHd4zBKhb8CGgURNi9l8UWtFn1YZb1ttc")
                // setDatabaseURL(...)
                // setStorageBucket(...)
                .build();
        boolean hasBeenInitialized = false;
        List<FirebaseApp> fbsLcl = FirebaseApp.getApps(getApplicationContext());
        for (FirebaseApp app : fbsLcl) {
            if (app.getName().equals("Medod")) {
                hasBeenInitialized = true;
            }
            if (!hasBeenInitialized) {
                FirebaseApp.initializeApp(getApplicationContext(), options, "Medod");
            } else {
                FirebaseApp.getInstance("Medod");
            }
        }
        FirebaseApp ap = FirebaseApp.getInstance("Medod");
        secondaryDatabase = FirebaseDatabase.getInstance(ap);
        ref = secondaryDatabase.getReference();
        storageReference = FirebaseStorage.getInstance().getReference().child("Product Images");
        //delete
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(productlistdetails.this);
                dialog.setTitle("Are You Sure!!");
                dialog.setMessage("Deleting this Item!!");
                dialog.setCancelable(false);
                dialog.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ref.child("products").child(ct).child(pid).removeValue().
                                addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful())
                                {
                                    finish();
                                    toast= Toast.makeText(getApplicationContext(),"Deleted Successfully..",
                                            Toast.LENGTH_SHORT);
                                    toast.show();
                                }
                            }
                        });
                    }
                });
                dialog.setNegativeButton("No Please!!", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                AlertDialog alertDialog = dialog.create();
                alertDialog.show();
            }
        });
        //onclickupdate
        upd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(nam.getText().toString().equals(nm) && dispri.getText().toString().equals(dispr)
                        && desc.getText().toString().equals(des) && ogproprice.getText().toString().equals(ogpri)
                        && prooverview.getText().toString().equals(overview) && prodingredients.getText().toString().equals(inge)
                        && prodosage.getText().toString().equals(dosag) && prolife.getText().toString().equals(lfe)
                        && proinfo.getText().toString().equals(info) && pronetquantity.getText().toString().equals(netqt)
                        && probrandabout.getText().toString().equals(abtbrnd) && procaution.getText().toString().equals(caution)
                        && procertification.getText().toString().equals(certifi))
                {
                    toast = Toast.makeText(getApplicationContext(),"Data Exist (कृपया अपडेट करें)!!",Toast.LENGTH_SHORT);
                    toast();
                }
                else {
                    update();
                }
            }
        });
    }
    private void update() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Updating (कृपया रुकिये)");
        dialog.setMessage("Hang On, Updating User Profile!!");
        dialog.setCancelable(false);
        alertDialog = dialog.create();
        alertDialog.show();
        HashMap<String , Object> promap = new HashMap<>();
        promap.put("pid",pid.toString());
        promap.put("date",dt.toString());
        promap.put("time",tm.toString());
        promap.put("description",desc.getText().toString());
        promap.put("image",im.toString());
        promap.put("category",ct.toString());
        promap.put("disprice",dispri.getText().toString());
        promap.put("proname",nam.getText().toString());
        promap.put("ogprice",ogproprice.getText().toString());
        promap.put("prooverview",prooverview.getText().toString());
        promap.put("proingredients",prodingredients.getText().toString());
        promap.put("prodosage",prodosage.getText().toString());
        promap.put("prolife",prolife.getText().toString());
        promap.put("pronetquantity",pronetquantity.getText().toString());
        promap.put("probrandabout",probrandabout.getText().toString());
        promap.put("procaution",procaution.getText().toString());
        promap.put("proinfo",proinfo.getText().toString());
        promap.put("procertification",procertification.getText().toString());
        ref.child("products").child(ct).child(pid).setValue(promap).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    alertDialog.dismiss();
                    toast=Toast.makeText(getApplicationContext(),"Update Successful!!",Toast.LENGTH_SHORT);
                    toast();
                    finish();
                }
                else
                {
                    alertDialog.dismiss();
                    Toast.makeText(getApplicationContext(),"Error>>"+task.getException().toString(),Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}