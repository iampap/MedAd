package com.example.medod_admin;

public class productlistdata {
    public String pid,date,time,description,image,category,disprice,proname,ogprice,prooverview,proingredients,prodosage,prolife
            ,pronetquantity,probrandabout,procaution,proinfo,procertification;
    public productlistdata() {
    }
    public productlistdata(String pid, String date, String time, String description, String image, String category, String disprice,
    String proname, String ogprice, String prooverview, String proingredients, String prodosage, String prolife, String pronetquantity,
    String probrandabout, String procaution, String proinfo, String procertification) {
        this.pid = pid;
        this.date = date;
        this.time = time;
        this.description = description;
        this.image = image;
        this.category = category;
        this.disprice = disprice;
        this.proname = proname;
        this.ogprice = ogprice;
        this.prooverview = prooverview;
        this.proingredients = proingredients;
        this.prodosage = prodosage;
        this.prolife = prolife;
        this.pronetquantity = pronetquantity;
        this.probrandabout = probrandabout;
        this.procaution = procaution;
        this.proinfo = proinfo;
        this.procertification = procertification;
    }
    public String getDisprice() {
        return disprice;
    }
    public void setDisprice(String disprice) {
        this.disprice = disprice;
    }
    public String getOgprice() {
        return ogprice;
    }
    public void setOgprice(String ogprice) {
        this.ogprice = ogprice;
    }
    public String getProoverview() {
        return prooverview;
    }
    public void setProoverview(String prooverview) {
        this.prooverview = prooverview;
    }
    public String getProingredients() {
        return proingredients;
    }
    public void setProingredients(String proingredients) {
        this.proingredients = proingredients;
    }
    public String getProdosage() {
        return prodosage;
    }
    public void setProdosage(String prodosage) {
        this.prodosage = prodosage;
    }
    public String getProlife() {
        return prolife;
    }
    public void setProlife(String prolife) {
        this.prolife = prolife;
    }
    public String getPronetquantity() {
        return pronetquantity;
    }
    public void setPronetquantity(String pronetquantity) {
        this.pronetquantity = pronetquantity;
    }
    public String getProbrandabout() {
        return probrandabout;
    }
    public void setProbrandabout(String probrandabout) {
        this.probrandabout = probrandabout;
    }
    public String getProcaution() {
        return procaution;
    }
    public void setProcaution(String procaution) {
        this.procaution = procaution;
    }
    public String getProinfo() {
        return proinfo;
    }
    public void setProinfo(String proinfo) {
        this.proinfo = proinfo;
    }
    public String getProcertification() {
        return procertification;
    }
    public void setProcertification(String procertification) {
        this.procertification = procertification;
    }
    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getProname() {
        return proname;
    }

    public void setProname(String proname) {
        this.proname = proname;
    }
}
