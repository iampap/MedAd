package com.example.medod_admin;

public class userdetailslistdata {
    private String City,LandMarg,PinCode,State,Street,Addressid;
    public userdetailslistdata() {
    }
    public userdetailslistdata(String city, String landMarg, String pinCode, String state, String street, String addressid) {
        City = city;
        LandMarg = landMarg;
        PinCode = pinCode;
        State = state;
        Street = street;
        Addressid = addressid;
    }
    public String getAddressid() {
        return Addressid;
    }
    public void setAddressid(String addressid) {
        Addressid = addressid;
    }
    public String getCity() {
        return City;
    }
    public void setCity(String city) {
        City = city;
    }
    public String getLandMarg() {
        return LandMarg;
    }
    public void setLandMarg(String landMarg) {
        LandMarg = landMarg;
    }
    public String getPinCode() {
        return PinCode;
    }
    public void setPinCode(String pinCode) {
        PinCode = pinCode;
    }
    public String getState() {
        return State;
    }
    public void setState(String state) {
        State = state;
    }
    public String getStreet() {
        return Street;
    }
    public void setStreet(String street) {
        Street = street;
    }
}