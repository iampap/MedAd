package com.example.medod_admin;

public class productdata {
    String category,pid,price;
    public productdata() {
    }

    public productdata(String category, String pid,String price) {
        this.category = category;
        this.pid = pid;
        this.price=price;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }
}
