package com.example.medod_admin;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class userdetails extends Fragment {
    //recycler
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    //firebase
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    private DatabaseReference dref, ref;
    //another database
    FirebaseDatabase secondaryDatabase;
    //toast
    private Toast toast;
    //string contain current user
    private String user;
    //image refresh
    private ImageView refrs;
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_userdetails, null);
        //binding
        refrs = view.findViewById(R.id.refresh);
        refrs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ref.child("UserDetails").removeValue();
                // Reload current fragment
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.nav_host_fragment, new userdetails()).remove(userdetails.this);
                ft.commit();
            }
        });
        //recycler
        recyclerView = view.findViewById(R.id.userdetailrecycler);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        //firebase
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        user = fuser.getUid();
        ref = FirebaseDatabase.getInstance().getReference();
        //getuserdetails
        getuserdet();
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        //getting details from another database
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setProjectId("medodd-d2fcc")
                .setApplicationId("1:468581190085:android:f71679ff61d4ba646c63ac")
                .setDatabaseUrl("https://medodd-d2fcc.firebaseio.com")
                .setApiKey("AIzaSyAHd4zBKhb8CGgURNi9l8UWtFn1YZb1ttc")
                // setDatabaseURL(...)
                // setStorageBucket(...)
                .build();
        boolean hasBeenInitialized = false;
        List<FirebaseApp> fbsLcl = FirebaseApp.getApps(getContext());
        for (FirebaseApp app : fbsLcl) {
            if (app.getName().equals("Medod")) {
                hasBeenInitialized = true;
            }
            if (!hasBeenInitialized) {
                FirebaseApp.initializeApp(getContext(), options, "Medod");
            } else {
                FirebaseApp.getInstance("Medod");
            }
        }
        FirebaseApp ap = FirebaseApp.getInstance("Medod");
        secondaryDatabase = FirebaseDatabase.getInstance(ap);
        final List<userdetailsdata> pidlist = new ArrayList<>();
        dref = secondaryDatabase.getReference();
        dref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child("User").exists()) {
                    dref.child("User").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                                userdetailsdata user = postSnapshot.child("Profile").getValue(userdetailsdata.class);
                                pidlist.add(user);
                                String[] q = new String[pidlist.size()];
                                for (int i = 0; i < pidlist.size(); i++) {
                                    q[i] = String.valueOf(pidlist.get(i).getUserid());
                                    //putting value in database
                                    HashMap<String, String> map = new HashMap<>();
                                    map.put("id", q[i]);
                                    ref.child("UserDetails").child("id" + i).setValue(map);
                                }
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void getuserdet() {
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child("UserDetails").exists()) {
                    FirebaseRecyclerOptions<userdetailsdata> optioncart = new FirebaseRecyclerOptions.Builder<userdetailsdata>()
                            .setQuery(ref.child("UserDetails"), userdetailsdata.class).build();
                    FirebaseRecyclerAdapter<userdetailsdata, userdetailsveiwholder> adapter = new FirebaseRecyclerAdapter<userdetailsdata, userdetailsveiwholder>(optioncart) {
                        @Override
                        protected void onBindViewHolder(@NonNull final userdetailsveiwholder userdetailsveiwholder, final int i,
                                                        @NonNull final userdetailsdata userdetailsdata) {
                            userdetailsveiwholder.id.setText("ID : " + userdetailsdata.getId());
                            userdetailsveiwholder.itemView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent in = new Intent(getContext(), userdetailslist.class);
                                    in.putExtra("id", userdetailsdata.id);
                                    startActivity(in);
                                }
                            });
                        }

                        @NonNull
                        @Override
                        public userdetailsveiwholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.userdetailsdata, parent, false);
                            userdetailsveiwholder holder = new userdetailsveiwholder(view);
                            return holder;
                        }
                    };
                    recyclerView.setAdapter(adapter);
                    adapter.startListening();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    //toast setup
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}