package com.example.medod_admin;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class home extends Fragment {
    //binding
    private TextView na,usrct,proct,pin;
    private ImageView usrimg;
    //database
    private DatabaseReference references;
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    //another database
    FirebaseDatabase secondaryDatabase;
    //    getting pincode data
    private ArrayList<String> pincode = new ArrayList<String>();
    //dialog
    private Dialog dialog;
    @Override
    public void onStart() {
        super.onStart();
//database binding
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        //if the current user is empty
        if (fuser != null) {
            //getting username from database
            references = FirebaseDatabase.getInstance().getReference().child("Admin").child(fuser.getUid()).child("Profile");
            references.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    assert dataSnapshot != null;
                    //if the user image exist
                    if (dataSnapshot.child("image").exists()) {
                        //load image to image view
                        String im = dataSnapshot.child("image").getValue().toString();
                        Picasso.get().load(im).into(usrimg);
                    }
                    else {
                        Picasso.get().load(R.drawable.ic_perm_identity_black_24dp).into(usrimg);
                    }
                    //setting the user name
                    String usname = dataSnapshot.child("UserName").getValue().toString();
                    if(usname.contains(" ")){
                        String nam = usname.substring(0, usname.indexOf(" "));
                        na.setText("Hii  "+nam+" !!");
                    }
                    else {
                        na.setText("Hii  "+usname+" !!");
                    }
                    references.removeEventListener(this);
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(getContext(),databaseError.getMessage(),Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, null);
        //binding
        na=view.findViewById(R.id.name);
        usrimg=view.findViewById(R.id.imageid);
        usrct=view.findViewById(R.id.usercount);
        proct=view.findViewById(R.id.procount);
        pin=view.findViewById(R.id.pincodetxt);
        //firebase
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        //getting details from another database
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setProjectId("medodd-d2fcc")
                .setApplicationId("1:468581190085:android:f71679ff61d4ba646c63ac")
                .setDatabaseUrl("https://medodd-d2fcc.firebaseio.com")
                .setApiKey("AIzaSyAHd4zBKhb8CGgURNi9l8UWtFn1YZb1ttc")
                // setDatabaseURL(...)
                // setStorageBucket(...)
                .build();
        boolean hasBeenInitialized = false;
        List<FirebaseApp> fbsLcl = FirebaseApp.getApps(getContext());
        for (FirebaseApp app : fbsLcl) {
            if (app.getName().equals("Medod")) {
                hasBeenInitialized = true;
            }
            if (!hasBeenInitialized) {
                FirebaseApp.initializeApp(getContext(), options, "Medod");
            } else {
                FirebaseApp.getInstance("Medod");
            }}
        FirebaseApp ap = FirebaseApp.getInstance("Medod");
        secondaryDatabase = FirebaseDatabase.getInstance(ap);
        references = secondaryDatabase.getReference();
        //getting the counts
        getusercount();
        //getting product count
        getproductcount();
        //getting pincode count
        getpincode();
        //onclick pincode
        pin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showpincode();
            }
        });
        return view;
    }
    //show pincode
    private void showpincode() {
        // custom dialog
        dialog = new Dialog(getContext());
        dialog.setContentView(R.layout.pincodedisplayhomepagecustomdialog);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(false);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        // set the custom dialog components - text, image and button
        TextView picode = (TextView)dialog.findViewById(R.id.pincodelist);
        /*StringBuilder jokeStringBuilder = new StringBuilder();
        for (int i=0; i<pincode.size();i++) {*/
            picode.setText(pincode.toString());
//        }
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.CENTER;
        dialog.getWindow().setAttributes(lp);
        Button dialogButton = (Button) dialog.findViewById(R.id.ok);
        // if button is clicked, close the custom dialog
        dialogButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }
    //geeting pincode from database in array
    private void getpincode() {
        references.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.child("pincode").exists())
                {
                    String count = String.valueOf(dataSnapshot.child("pincode").child("Pincode").getChildrenCount());
                    pin.setText("Pin-Code Dilevery Available in "+count+" Area across India     >");
                    for(DataSnapshot ds : dataSnapshot.child("pincode").child("Pincode").getChildren()) {
                        String pico = ds.getValue().toString();
                        pincode.add(pico);
                    }
                }
                else {
                    pin.setText("No Pin-Code Area Added Yet!!");
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    private void getproductcount() {
        references.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child("products").exists()) {
                    String count = String.valueOf(dataSnapshot.child("products").getChildrenCount());
                    proct.setText(count);
                }
                else {
                    usrct.setText("शून्य");
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    private void getusercount() {
        references.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child("User").exists()) {
                    String count = String.valueOf(dataSnapshot.child("User").getChildrenCount());
                    usrct.setText(count);
                }
                else {
                    usrct.setText("शून्य");
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}