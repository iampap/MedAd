package com.example.medod_admin;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;


public class product extends Fragment {
    //binding
    private Button addprod;
    private String currenttime, currentdate,productid ;
    private EditText text;
    //recycler
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    //firebase
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    private DatabaseReference ref;
    //another database
    private FirebaseDatabase secondaryDatabase;
    //toast
    private Toast toast;
    //string contain current user
    private String user;
    //refresh
    private ImageView refreshproduct;
    //dialog
    private Dialog dialog;
    @Override
    public void onStart() {
        super.onStart();
    }
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_product, null);
        //binding
        addprod = view.findViewById(R.id.addpro);
        addprod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customdialog();
            }
        });
        //brefresh
        refreshproduct = view.findViewById(R.id.refreshpro);
        refreshproduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Reload current fragment
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.nav_host_fragment,new product()).remove(product.this);
                ft.commit();
            }
        });
        //recycler
        recyclerView = view.findViewById(R.id.productrecycler);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        //firebase
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        user = fuser.getUid();
        //getting details from another database
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setProjectId("medodd-d2fcc")
                .setApplicationId("1:468581190085:android:f71679ff61d4ba646c63ac")
                .setDatabaseUrl("https://medodd-d2fcc.firebaseio.com")
                .setApiKey("AIzaSyAHd4zBKhb8CGgURNi9l8UWtFn1YZb1ttc")
                // setDatabaseURL(...)
                // setStorageBucket(...)
                .build();
        boolean hasBeenInitialized = false;
        List<FirebaseApp> fbsLcl = FirebaseApp.getApps(getContext());
        for (FirebaseApp app : fbsLcl) {
            if (app.getName().equals("Medod")) {
                hasBeenInitialized = true;
            }
            if (!hasBeenInitialized) {
                FirebaseApp.initializeApp(getContext(), options, "Medod");
            } else {
                FirebaseApp.getInstance("Medod");
            }
        }
        FirebaseApp ap = FirebaseApp.getInstance("Medod");
        secondaryDatabase = FirebaseDatabase.getInstance(ap);
        ref = secondaryDatabase.getReference();
        //getting product details
        productdet();
        return view;
    }
    private void customdialog() {
// custom dialog
        dialog = new Dialog(getContext());
        dialog.setContentView(R.layout.productadddisplay);
        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        // set the custom dialog components - text, image and button
        text =(EditText) dialog.findViewById(R.id.textitem);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.CENTER;
        dialog.getWindow().setAttributes(lp);
        Button dialogButton = (Button) dialog.findViewById(R.id.addbt);
        // if button is clicked, close the custom dialog
        dialogButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(text.getText().toString().isEmpty())
                {
                    text.setError("Please Add Product Name!!");
                    text.requestFocus();
                    return;
                }
                else {
                    addproduct();
                }
            }
        });
        dialog.show();
    }
    private void addproduct() {
             Calendar calfordate = Calendar.getInstance();
        SimpleDateFormat currdate = new SimpleDateFormat(" dd:MMM:yyyy");
        currentdate = currdate.format(calfordate.getTime());
        SimpleDateFormat currtime = new SimpleDateFormat("HH:MM:SS:a");
        currenttime = currtime.format(calfordate.getTime());
        //timestamp
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("ddMMyyyyhhmmss");
        String tss = simpleDateFormat.format(calfordate.getTime());
        try{
            final Date date = simpleDateFormat.parse(tss);
            long ts = date.getTime();
            productid=String.valueOf(ts);
        }catch(ParseException e){
            e.printStackTrace();
        }
        String name = text.getText().toString().trim();
        HashMap<String, String> map3  = new HashMap<>();
        map3.put("pid",productid);
        map3.put("date",currentdate);
        map3.put("time",currenttime);
        map3.put("description","null");
        map3.put("image","null");
        map3.put("category",text.getText().toString());
        map3.put("price","null");
        map3.put("proname","null");
        ref.child("products").child(name).child(productid).setValue(map3).
                addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    dialog.dismiss();
                    toast=Toast.makeText(getActivity(),"Prdouct Added!!",Toast.LENGTH_SHORT);
                    toast.show();
                    // Reload current fragment
                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                    ft.replace(R.id.nav_host_fragment,new product()).remove(product.this);
                    ft.commit();
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
            dialog.dismiss();
                toast=Toast.makeText(getActivity(),"Prdouct Not Added!!",Toast.LENGTH_SHORT);
                toast.show();
                // Reload current fragment
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.nav_host_fragment,new product()).remove(product.this);
                ft.commit();
            }
        });
    }
    private void productdet() {
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.child("products").exists())
                {
                    final ArrayList<String> pidlist = new ArrayList<String>();
                    ref.child("products").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            for (final DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                                String user = postSnapshot.getKey().toString();
                                long count = dataSnapshot.getChildrenCount();
                                pidlist.add(user);
                                for (int i = 0; i < pidlist.size(); i++) {
                                    FirebaseRecyclerOptions<productdata> optioncart = new FirebaseRecyclerOptions.Builder<productdata>()
                                            .setQuery(ref.child("products"), productdata.class).build();
                                    FirebaseRecyclerAdapter<productdata, productviewholder>
                                            adapter = new FirebaseRecyclerAdapter<productdata, productviewholder>(optioncart) {
                                        @Override
                                        protected void onBindViewHolder(@NonNull final productviewholder productviewholder, final int i,
                                                                        @NonNull final productdata productdata) {
                                            ref.child("products").child(pidlist.get(i).toString()).addListenerForSingleValueEvent(new ValueEventListener() {
                                                @Override
                                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                    productviewholder.procount.setText("Item Available : "+dataSnapshot.getChildrenCount());
                                                }
                                                @Override
                                                public void onCancelled(@NonNull DatabaseError databaseError) {
                                                    Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
                                                }
                                            });
                                            productviewholder.proname.setText("Product Name : " + pidlist.get(i).toString());
                                            productviewholder.itemView.setOnClickListener(new View.OnClickListener() {
                                                @Override
                                                public void onClick(View v) {
                                                    Intent in = new Intent(getContext(), productlist.class);
                                                    in.putExtra("productname",pidlist.get(i).toString());
                                                    startActivity(in);
                                                }
                                            });
                                        }
                                        @NonNull
                                        @Override
                                        public productviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                                            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.productdata, parent, false);
                                            productviewholder holder = new productviewholder(view);
                                            return holder;
                                        }
                                    };
                                    recyclerView.setAdapter(adapter);
                                    adapter.startListening();
                                }
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}