package com.example.medod_admin;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class userorderlistviewholder extends RecyclerView.ViewHolder implements View.OnClickListener {
    TextView odid,procount,odsta;
    public itemclicklistner orderlist;
    public userorderlistviewholder(@NonNull View itemView) {
        super(itemView);
        odid=itemView.findViewById(R.id.odid);
        procount=itemView.findViewById(R.id.orderlistcount);
        odsta=itemView.findViewById(R.id.odstatus);
    }
    @Override
    public void onClick(View v) {
    }
    public void setOrderlist(itemclicklistner orderlist) {
        this.orderlist = orderlist;
    }
}
