package com.example.medod_admin;

public class userorderdata {
    private String userid,PhoneNumber,UserEmail,UserName;
    public userorderdata() {
    }
    public userorderdata(String userid, String phoneNumber, String userEmail, String userName) {
        this.userid = userid;
        PhoneNumber = phoneNumber;
        UserEmail = userEmail;
        UserName = userName;
    }
    public String getUserid() {
        return userid;
    }
    public void setUserid(String userid) {
        this.userid = userid;
    }
    public String getPhoneNumber() {
        return PhoneNumber;
    }
    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }
    public String getUserEmail() {
        return UserEmail;
    }
    public void setUserEmail(String userEmail) {
        UserEmail = userEmail;
    }
    public String getUserName() {
        return UserName;
    }
    public void setUserName(String userName) {
        UserName = userName;
    }
}
