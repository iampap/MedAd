package com.example.medod_admin;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class productlistviewholder extends RecyclerView.ViewHolder implements View.OnClickListener {
    TextView itemname;
    public itemclicklistner productlistdet;
    public productlistviewholder(@NonNull View itemView) {
        super(itemView);
        itemname=itemView.findViewById(R.id.itemname);
    }
    @Override
    public void onClick(View v) {
    }
    public void setProductlistdet(itemclicklistner productlistdet) {
        this.productlistdet = productlistdet;
    }
}
