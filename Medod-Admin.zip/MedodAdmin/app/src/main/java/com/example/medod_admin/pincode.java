package com.example.medod_admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewDebug;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class pincode extends AppCompatActivity {
    //binding
    private EditText pin;
    private Button up;
    private String pcode;
    //firebase
    private DatabaseReference references;
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    //another database
    FirebaseDatabase secondaryDatabase;
    //alertdialoge
    private AlertDialog alertDialog;
    //Toast
    private Toast toast;
    //array
    private ArrayList<String> pincode = new ArrayList<String>();
    //progress bar
    private ProgressDialog bar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pincode);
        //binding
        pin = (EditText) findViewById(R.id.pincodeenter);
        up = (Button) findViewById(R.id.pinsubmit);
        bar = new ProgressDialog(this);
        //firebase binding
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        //getting details from another database
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setProjectId("medodd-d2fcc")
                .setApplicationId("1:468581190085:android:f71679ff61d4ba646c63ac")
                .setDatabaseUrl("https://medodd-d2fcc.firebaseio.com")
                .setApiKey("AIzaSyAHd4zBKhb8CGgURNi9l8UWtFn1YZb1ttc")
                // setDatabaseURL(...)
                // setStorageBucket(...)
                .build();
        boolean hasBeenInitialized = false;
        List<FirebaseApp> fbsLcl = FirebaseApp.getApps(getApplicationContext());
        for (FirebaseApp app : fbsLcl) {
            if (app.getName().equals("Medod")) {
                hasBeenInitialized = true;
            }
            if (!hasBeenInitialized) {
                FirebaseApp.initializeApp(getApplicationContext(), options, "Medod");
            } else {
                FirebaseApp.getInstance("Medod");
            }}
        FirebaseApp ap = FirebaseApp.getInstance("Medod");
        secondaryDatabase = FirebaseDatabase.getInstance(ap);
        references = secondaryDatabase.getReference();
        //on click
        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateuser();
            }
        });
        //get data in array pincode
        getpincode();
    }
    //geeting pincode from database in array
    private void getpincode() {
        references.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.child("pincode").exists())
                {
                    references.child("pincode").child("Pincode").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            for(DataSnapshot ds : dataSnapshot.getChildren()) {
                                String pico = ds.getValue().toString();
                                pincode.add(pico);
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();                        }
                    });
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    //update data in user profile
    private void updateuser() {
        pcode = pin.getText().toString().trim();
        if (pcode.length() < 6) {
            pin.setError("Pincode Please..");
            pin.requestFocus();
            return;
        } else {
            bar.setTitle("Adding New Items");
            bar.setMessage("Plz Wait....while we r adding the items!");
            bar.setCanceledOnTouchOutside(false);
            bar.setCancelable(false);
            bar.show();
            saveproinfodatbase();
        }
    }
    //saving all the pincode in the user database
    private void saveproinfodatbase() {
        Integer flag = 0 ;
        for( int i=0 ; i<pincode.size() ; i++)
        {
            if(pcode.equals(pincode.get(i)))
            {
                flag=1;
                break;
            }
        }
        if(flag.equals(1))
        {
            bar.dismiss();
            toast=Toast.makeText(getApplicationContext(),"Pin-Code Already Exist!!",Toast.LENGTH_SHORT);
            toast();
        }
        else {
            int s = pincode.size() + 1;
            for(int i=pincode.size() ; i<s ; i++)
            {
                pincode.add(i,pcode);
            }
            HashMap<String, ArrayList<String>> map = new HashMap<>();
            map.put("Pincode", pincode);
            references.child("pincode").setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful())
                    {
                        bar.dismiss();
                        toast=Toast.makeText(getApplicationContext(),"Update Successful!!",Toast.LENGTH_SHORT);
                        toast();
                    }
                    else
                    {
                        bar.dismiss();
                        Toast.makeText(getApplicationContext(),"Error>>"+task.getException().toString(),Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}