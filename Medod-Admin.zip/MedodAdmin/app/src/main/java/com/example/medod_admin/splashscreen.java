package com.example.medod_admin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;

public class splashscreen extends AppCompatActivity {
    private static int SPLASH_SCREEN_TIME_OUT=1000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splashscreen);
        //checking the version
        if(Build.VERSION.SDK_INT >= 21)
            //setting the window fullscreen and status bar null
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        //which xml file to layout on splash screen for that time
        setContentView(R.layout.activity_splashscreen);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() { Intent i=new Intent(splashscreen.this, login.class);
                startActivity(i);
                finish();
            };
        }, SPLASH_SCREEN_TIME_OUT);
    }
    }
