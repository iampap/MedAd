package com.example.medod_admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.List;

public class userdetailslist extends AppCompatActivity {
    //binding
    private TextView usrid,usremail,upbutton,ordernos;
    private ImageView usrimage;
    private EditText usrname,usrmobno;
    private Button addaddr;
    private String email , usname , mobno,ima;
    //firebase
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    private DatabaseReference dref, ref;
    //recycler address
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    //intentstring
    private String userid;
    //another database
    private FirebaseDatabase secondaryDatabase;
    //alertdialoge
    private AlertDialog alertDialog;
    //toast
    private Toast toast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userdetailslist);
        //binding
        usrid = findViewById(R.id.userid);
        usremail = findViewById(R.id.useremail);
        upbutton = findViewById(R.id.updatebutton);
        usrimage = findViewById(R.id.userimage);
        usrname = findViewById(R.id.username);
        usrmobno = findViewById(R.id.usermobno);
        addaddr=findViewById(R.id.addadress);
        ordernos=findViewById(R.id.orderno);
        //onclick
        addaddr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(userdetailslist.this,userdetailaddaddress.class);
                in.putExtra("userid",userid);
                startActivity(in);
            }
        });
        upbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate();
            }
        });
        //getting intent
        userid = getIntent().getStringExtra("id");
        usrid.setText("User ID : "+userid.toString());
        //recycler
        recyclerView = findViewById(R.id.useraddres);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        //secondary database
        //getting details from another database
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setProjectId("medodd-d2fcc")
                .setApplicationId("1:468581190085:android:f71679ff61d4ba646c63ac")
                .setDatabaseUrl("https://medodd-d2fcc.firebaseio.com")
                .setApiKey("AIzaSyAHd4zBKhb8CGgURNi9l8UWtFn1YZb1ttc")
                // setDatabaseURL(...)
                // setStorageBucket(...)
                .build();
        boolean hasBeenInitialized = false;
        List<FirebaseApp> fbsLcl = FirebaseApp.getApps(getApplicationContext());
        for (FirebaseApp app : fbsLcl) {
            if (app.getName().equals("Medod")) {
                hasBeenInitialized = true;
            }
            if (!hasBeenInitialized) {
                FirebaseApp.initializeApp(getApplicationContext(), options, "Medod");
            } else {
                FirebaseApp.getInstance("Medod");
            }
            FirebaseApp ap = FirebaseApp.getInstance("Medod");
            secondaryDatabase = FirebaseDatabase.getInstance(ap);

        }
        //database
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        ref =FirebaseDatabase.getInstance().getReference();
        dref = secondaryDatabase.getReference();
    }

    private void validate() {
        email = usremail.getText().toString().trim();
        usname = usrname.getText().toString().trim();
        mobno=usrmobno.getText().toString().trim();
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        if (email.isEmpty()) {
            usremail.setError("Email please..");
            usremail.requestFocus();
            return;
        }
        else if (!email.matches(emailPattern)) {
            usremail.setError("Invalid Email");
            usremail.requestFocus();
            return;
        }
        else if (usname.isEmpty()) {
            usrname.setError("Password please..");
            usrname.requestFocus();
            return;
        }
        else if (mobno.isEmpty()) {
            usrmobno.setError("Mob No please..");
            usrmobno.requestFocus();
            return;
        }
        else{
            AlertDialog.Builder dialog = new AlertDialog.Builder(this);
            dialog.setTitle("Updating (कृपया रुकिये)");
            dialog.setMessage("Hang On, Updating User Profile!!");
            dialog.setCancelable(false);
            alertDialog = dialog.create();
            alertDialog.show();
            update();
        }
    }

    private void update() {
        HashMap<String, String> map = new HashMap<>();
        map.put("UserName", usname);
        map.put("UserEmail", email);
        map.put("PhoneNumber", mobno);
        map.put("userid",userid);
        map.put("image",ima);
        dref.child("User").child(userid).child("Profile").setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    alertDialog.dismiss();
                    toast=Toast.makeText(getApplicationContext(),"Update Successful!!",Toast.LENGTH_SHORT);
                    toast();
                }
                else
                {
                    alertDialog.dismiss();
                    Toast.makeText(getApplicationContext(),"Error>>"+task.getException().toString(),Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    @Override
    protected void onStart() {
        super.onStart();
        dref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.child("User").exists())
                {
                    usrname.setText(dataSnapshot.child("User").child(userid).child("Profile")
                            .child("UserName").getValue().toString());
                    usremail.setText(dataSnapshot.child("User").child(userid).child("Profile")
                            .child("UserEmail").getValue().toString());
                    usrmobno.setText(dataSnapshot.child("User").child(userid).child("Profile")
                            .child("PhoneNumber").getValue().toString());
                    if(dataSnapshot.child("User").child(userid).child("Profile")
                            .child("image").exists())
                    {
                        ima = dataSnapshot.child("User").child(userid).child("Profile")
                                .child("image").getValue().toString();
                        Picasso.get().load(ima).into(usrimage);
                    }
                }
                else {
                    toast= Toast.makeText(getApplicationContext(),"No User",Toast.LENGTH_SHORT);
                    toast.show();
                }
                if(dataSnapshot.child("Orders").child(userid).exists())
                {
                    long no = dataSnapshot.child("Orders").child(userid).getChildrenCount();
                        ordernos.setText("No of Orders placed by User : "+ no );
                }
                else {
                    ordernos.setText("No Orders Placed By the User!!");
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(),databaseError.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
        getAddress();
    }

    private void getAddress() {
        dref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.child("User").child(userid).child("Address").exists())
                {
                    FirebaseRecyclerOptions<userdetailslistdata> optioncart = new FirebaseRecyclerOptions.Builder<userdetailslistdata>()
                            .setQuery(dref.child("User").child(userid).child("Address"), userdetailslistdata.class).build();
                    FirebaseRecyclerAdapter<userdetailslistdata, userdetailslistviewholder> adapter = new
                            FirebaseRecyclerAdapter<userdetailslistdata, userdetailslistviewholder>(optioncart) {
                        @Override
                        protected void onBindViewHolder(@NonNull userdetailslistviewholder userdetailsdataviewholder,
                                                        int i, @NonNull final userdetailslistdata userdetailslistdata) {
                            //getting value from database
                            userdetailsdataviewholder.streetad.setText("Address : "+userdetailslistdata.getStreet());
                            userdetailsdataviewholder.lm.setText("LandMarg : "+userdetailslistdata.getLandMarg());
                            userdetailsdataviewholder.sta.setText("State : "+userdetailslistdata.getState());
                            userdetailsdataviewholder.pc.setText("PinCode : "+userdetailslistdata.getPinCode());
                            userdetailsdataviewholder.cy.setText("City : "+userdetailslistdata.getCity());
                            final String addressid = userdetailslistdata.getAddressid();
                            userdetailsdataviewholder.adedit.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent in = new Intent(userdetailslist.this,userdetaillisteditaddress.class);
                                    in.putExtra("addreddid",addressid);
                                    in.putExtra("address",userdetailslistdata.getStreet());
                                    in.putExtra("landmarg",userdetailslistdata.getLandMarg());
                                    in.putExtra("state",userdetailslistdata.getState());
                                    in.putExtra("pincode",userdetailslistdata.getPinCode());
                                    in.putExtra("city",userdetailslistdata.getCity());
                                    in.putExtra("userid",userid);
                                    startActivity(in);
                                }
                            });
                            userdetailsdataviewholder.addel.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    dref.child("User").child(userid).child("Address").child(addressid).removeValue();
                                    //toast
                                    toast = Toast.makeText(getApplicationContext(),"Address Deleted!!", Toast.LENGTH_SHORT);
                                    toast();
                                    //refresh
                                    Intent intent = getIntent();
                                    finish();
                                    overridePendingTransition(0, 0);
                                    startActivity(intent);
                                    overridePendingTransition(0, 0);
                                }
                            });
                        }
                        @NonNull
                        @Override
                        public userdetailslistviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                            View view = LayoutInflater.from(parent.getContext()).inflate
                                    (R.layout.userdetailslistdata, parent, false);
                            userdetailslistviewholder holder = new userdetailslistviewholder(view);
                            return holder;
                        }
                    };
                    //recycler setting
                    recyclerView.setAdapter(adapter);
                    adapter.startListening();
                }else {
                    toast=Toast.makeText(getApplicationContext(),"No Address",Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(),databaseError.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}