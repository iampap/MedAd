package com.example.medod_admin;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class userorderviewholder extends RecyclerView.ViewHolder implements View.OnClickListener {
    TextView id,name,email,count;
    LinearLayout ll;
    public itemclicklistner userorderview;
    public userorderviewholder(@NonNull View itemView) {
        super(itemView);
        id=itemView.findViewById(R.id.odusid);
        count=itemView.findViewById(R.id.ordercount);
        name=itemView.findViewById(R.id.odusname);
        email=itemView.findViewById(R.id.odusem);
        ll=itemView.findViewById(R.id.userodll);
    }
    @Override
    public void onClick(View v) {
    }
    public void setUserorderview(itemclicklistner userorderview) {
        this.userorderview = userorderview;
    }
}