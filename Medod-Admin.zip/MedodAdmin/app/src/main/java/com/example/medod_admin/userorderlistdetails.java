package com.example.medod_admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class userorderlistdetails extends AppCompatActivity {
    //binding
    private TextView orderid,pid,disp,odshipped,outdilv,deliveredpro,proofpri,sold
            ,usoddate,usrname,add,lm,cy,pincd,usrmobno,odpri,odshipping,tot,cashbk,pymd,usodtime,odst,odcancel,retod,deldt;
    private  ImageView proim;
    private String addid,delidate,state,usoddates,adds,lms,cys,pincds,odshippings,tots,cashbks,usodtimes,odsts,pymentmd;
    //recycler
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    //firebase
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    private DatabaseReference dref;
    //another database
    FirebaseDatabase secondaryDatabase;
    //toast
    private Toast toast;
    //string contain current user
    private String user,uid,uname,uemail,oid;
    //image refresh
    private ImageView refrs;
    //dialog
    private Dialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userorderlistdetails);
        //binding
        orderid=findViewById(R.id.userorderid);
        usoddate= findViewById(R.id.userorderdate);
        usodtime= findViewById(R.id.userordertime);
        usrname= findViewById(R.id.deliveryitemto);
        add= findViewById(R.id.address);
        lm= findViewById(R.id.usrlandmarg);
        cy= findViewById(R.id.usrcity);
        pincd= findViewById(R.id.usrpincode);
        usrmobno= findViewById(R.id.usrmobno);
        odpri= findViewById(R.id.odprice);
        odshipping= findViewById(R.id.shipping);
        tot= findViewById(R.id.total);
        cashbk= findViewById(R.id.cashback);
        pymd= findViewById(R.id.paymentmode);
        odst= findViewById(R.id.odstatus);
        odcancel=findViewById(R.id.odcanceled);
        retod=findViewById(R.id.odreturn);
        deldt = findViewById(R.id.delidate);
        //get intent
        uid=getIntent().getStringExtra("userid");
        oid=getIntent().getStringExtra("orderid");
        uname=getIntent().getStringExtra("username");
        uemail=getIntent().getStringExtra("useremail");
        //set email
        orderid.setText("Order-ID : "+oid.toString());
        //refresh
        refrs = findViewById(R.id.refreshodpro);
        refrs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Reload current fragment
                Intent intent = getIntent();
                finish();
                overridePendingTransition(0, 0);
                startActivity(intent);
                overridePendingTransition(0, 0);
            }
        });
        //recycler
        recyclerView = findViewById(R.id.odprorecycler);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        //firebase
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        user = fuser.getUid();
        //getting details from another database
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setProjectId("medodd-d2fcc")
                .setApplicationId("1:468581190085:android:f71679ff61d4ba646c63ac")
                .setDatabaseUrl("https://medodd-d2fcc.firebaseio.com")
                .setApiKey("AIzaSyAHd4zBKhb8CGgURNi9l8UWtFn1YZb1ttc")
                // setDatabaseURL(...)
                // setStorageBucket(...)
                .build();
        boolean hasBeenInitialized = false;
        List<FirebaseApp> fbsLcl = FirebaseApp.getApps(getApplicationContext());
        for (FirebaseApp app : fbsLcl) {
            if (app.getName().equals("Medod")) {
                hasBeenInitialized = true;
            }
            if (!hasBeenInitialized) {
                FirebaseApp.initializeApp(getApplicationContext(), options, "Medod");
            } else {
                FirebaseApp.getInstance("Medod");
            }}
        FirebaseApp ap = FirebaseApp.getInstance("Medod");
        secondaryDatabase = FirebaseDatabase.getInstance(ap);
        dref = secondaryDatabase.getReference();
        //onclick order status
        odst.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dref.child("User").child(uid).child("Orders").child(oid).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.child("orderstatus").getValue().toString().equals("Cancelled"))
                        {
                            toast=Toast.makeText(getApplicationContext(),"Order is Cancelled Already!!",Toast.LENGTH_SHORT);
                            toast.show();
                        }
                        else if(dataSnapshot.child("orderstatus").getValue().toString().equals("Return"))
                        {
                            toast=Toast.makeText(getApplicationContext(),"Return is in Process!!",Toast.LENGTH_SHORT);
                            toast.show();
                        }
                        else
                        {
                            dialog = new Dialog(userorderlistdetails.this);
                            dialog.setContentView(R.layout.userorderlistdetailsorderstatus);
                            dialog.setCanceledOnTouchOutside(false);
                            dialog.setCancelable(false);
                            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                            // set the custom dialog components - text, image and button
                            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                            lp.copyFrom(dialog.getWindow().getAttributes());
                            lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                            lp.gravity = Gravity.CENTER;
                            dialog.getWindow().setAttributes(lp);
                            Button deliv = (Button) dialog.findViewById(R.id.Delivered);
                            Button conf = (Button) dialog.findViewById(R.id.Confirm);
                            Button can = dialog.findViewById(R.id.canc);
                            conf.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    final AlertDialog.Builder dialogal = new AlertDialog.Builder(userorderlistdetails.this);
                                    dialogal.setTitle("Are You Sure!!");
                                    dialogal.setMessage("Confirm the Order!!");
                                    dialogal.setCancelable(false);
                                    dialogal.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(final DialogInterface dialogal, int which) {
                                            HashMap<String, String> map3  = new HashMap<>();
                                            map3.put("orderstatus","Confirm");
                                            map3.put("TotalPrice",tots);
                                            map3.put("Orderid", oid);
                                            map3.put("Orderdate",usoddates);
                                            map3.put("Ordertime", usodtimes);
                                            map3.put("DeliveryDate", delidate);
                                            map3.put("Street", adds);
                                            map3.put("LandMarg", lms);
                                            map3.put("City", cys);
                                            map3.put("State", state);
                                            map3.put("PinCode", pincds);
                                            map3.put("Addressid", addid);
                                            map3.put("Shipping",odshippings);
                                            map3.put("Cashback",cashbks);
                                            map3.put("paymentmode",pymentmd);
                                            dref.child("User").child(uid).child("Orders").child(oid).setValue(map3).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if(task.isSuccessful())
                                                    {
                                                        dialogal.dismiss();
                                                        dialog.dismiss();
                                                        // Reload current fragment
                                                        Intent intent = getIntent();
                                                        finish();
                                                        overridePendingTransition(0, 0);
                                                        startActivity(intent);
                                                        overridePendingTransition(0, 0);
                                                    }
                                                }
                                            }).addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    dialogal.dismiss();
                                                    dialog.dismiss();
                                                    // Reload current fragment
                                                    Intent intent = getIntent();
                                                    finish();
                                                    overridePendingTransition(0, 0);
                                                    startActivity(intent);
                                                    overridePendingTransition(0, 0);
                                                }
                                            });
                                        }
                                    });
                                    dialogal.setNegativeButton("No Please!!", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                        }
                                    });
                                    AlertDialog alertDialog = dialogal.create();
                                    alertDialog.show();
                                }
                            });
                            deliv.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    AlertDialog.Builder dialogal = new AlertDialog.Builder(userorderlistdetails.this);
                                    dialogal.setTitle("Are You Sure!!");
                                    dialogal.setMessage("Order Delivered!!");
                                    dialogal.setCancelable(false);
                                    dialogal.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(final DialogInterface dialogal, int which) {
                                            HashMap<String, String> map3  = new HashMap<>();
                                            map3.put("orderstatus","Delivered");
                                            map3.put("TotalPrice",tots);
                                            map3.put("Orderid", oid);
                                            map3.put("Orderdate",usoddates);
                                            map3.put("Ordertime", usodtimes);
                                            map3.put("DeliveryDate", delidate);
                                            map3.put("Street", adds);
                                            map3.put("LandMarg", lms);
                                            map3.put("City", cys);
                                            map3.put("State", state);
                                            map3.put("PinCode", pincds);
                                            map3.put("Addressid", addid);
                                            map3.put("Shipping",odshippings);
                                            map3.put("Cashback",cashbks);
                                            map3.put("paymentmode",pymentmd);
                                            dref.child("User").child(uid).child("Orders").child(oid).setValue(map3).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if(task.isSuccessful())
                                                    {
                                                        dialogal.dismiss();
                                                        dialog.dismiss();
                                                        // Reload current fragment
                                                        Intent intent = getIntent();
                                                        finish();
                                                        overridePendingTransition(0, 0);
                                                        startActivity(intent);
                                                        overridePendingTransition(0, 0);
                                                    }
                                                }
                                            }).addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    dialogal.dismiss();
                                                    dialog.dismiss();
                                                    // Reload current fragment
                                                    Intent intent = getIntent();
                                                    finish();
                                                    overridePendingTransition(0, 0);
                                                    startActivity(intent);
                                                    overridePendingTransition(0, 0);
                                                }
                                            });
                                        }
                                    });
                                    dialogal.setNegativeButton("No Please!!", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                        }
                                    });
                                    AlertDialog alertDialog = dialogal.create();
                                    alertDialog.show();
                                }
                            });
                            can.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    dialog.dismiss();
                                }
                            });
                            dialog.show();
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
        //order cancel
        odcancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dref.child("User").child(uid).child("Orders").child(oid).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.child("orderstatus").getValue().toString().equals("Cancelled"))
                        {
                            toast=Toast.makeText(getApplicationContext(),"Order is Cancelled Already!!",Toast.LENGTH_SHORT);
                            toast.show();
                        }
                        else{
                            AlertDialog.Builder dialogal = new AlertDialog.Builder(userorderlistdetails.this);
                            dialogal.setTitle("Are You Sure!!");
                            dialogal.setMessage("Cancel Order!!");
                            dialogal.setCancelable(false);
                            dialogal.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(final DialogInterface dialogal, int which) {
                                    HashMap<String, String> map3  = new HashMap<>();
                                    map3.put("orderstatus","Cancelled");
                                    map3.put("TotalPrice",tots);
                                    map3.put("Orderid", oid);
                                    map3.put("Orderdate",usoddates);
                                    map3.put("Ordertime", usodtimes);
                                    map3.put("DeliveryDate", delidate);
                                    map3.put("Street", adds);
                                    map3.put("LandMarg", lms);
                                    map3.put("City", cys);
                                    map3.put("State", state);
                                    map3.put("PinCode", pincds);
                                    map3.put("Addressid", addid);
                                    map3.put("Shipping",odshippings);
                                    map3.put("Cashback",cashbks);
                                    map3.put("paymentmode",pymentmd);
                                    dref.child("User").child(uid).child("Orders").child(oid).setValue(map3).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful())
                                            {
                                                dialogal.dismiss();
                                                // Reload current fragment
                                                Intent intent = getIntent();
                                                finish();
                                                overridePendingTransition(0, 0);
                                                startActivity(intent);
                                                overridePendingTransition(0, 0);
                                            }
                                        }
                                    }).addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            dialogal.dismiss();
                                            // Reload current fragment
                                            Intent intent = getIntent();
                                            finish();
                                            overridePendingTransition(0, 0);
                                            startActivity(intent);
                                            overridePendingTransition(0, 0);
                                        }
                                    });
                                }
                            });
                            dialogal.setNegativeButton("No Please!!", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                            AlertDialog alertDialog = dialogal.create();
                            alertDialog.show();
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
        //return order
        retod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dref.child("User").child(uid).child("Orders").child(oid).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.child("orderstatus").getValue().toString().equals("Delivered"))
                        {
                            AlertDialog.Builder dialogal = new AlertDialog.Builder(userorderlistdetails.this);
                            dialogal.setTitle("Are You Sure!!");
                            dialogal.setMessage("Return Order!!");
                            dialogal.setCancelable(false);
                            dialogal.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(final DialogInterface dialogal, int which) {
                                    HashMap<String, String> map3  = new HashMap<>();
                                    map3.put("orderstatus","Return");
                                    map3.put("TotalPrice",tots);
                                    map3.put("Orderid", oid);
                                    map3.put("Orderdate",usoddates);
                                    map3.put("Ordertime", usodtimes);
                                    map3.put("DeliveryDate", delidate);
                                    map3.put("Street", adds);
                                    map3.put("LandMarg", lms);
                                    map3.put("City", cys);
                                    map3.put("State", state);
                                    map3.put("PinCode", pincds);
                                    map3.put("Addressid", addid);
                                    map3.put("Shipping",odshippings);
                                    map3.put("Cashback",cashbks);
                                    map3.put("paymentmode",pymentmd);
                                    dref.child("User").child(uid).child("Orders").child(oid).setValue(map3).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful())
                                            {
                                                dialogal.dismiss();
                                                // Reload current fragment
                                                Intent intent = getIntent();
                                                finish();
                                                overridePendingTransition(0, 0);
                                                startActivity(intent);
                                                overridePendingTransition(0, 0);
                                            }
                                        }
                                    }).addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            dialogal.dismiss();
                                            // Reload current fragment
                                            Intent intent = getIntent();
                                            finish();
                                            overridePendingTransition(0, 0);
                                            startActivity(intent);
                                            overridePendingTransition(0, 0);
                                        }
                                    });
                                }
                            });
                            dialogal.setNegativeButton("No Please!!", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                            AlertDialog alertDialog = dialogal.create();
                            alertDialog.show();
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
        //getuserdetails
        getuseroddet();
        //getting order details
        orderdet();
    }
    //getting the order details
    private void orderdet() {
        dref.child("User").child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //getting data in string
                addid= dataSnapshot.child("Orders").child(oid).child("Addressid").getValue().toString();
                delidate = dataSnapshot.child("Orders").child(oid).child("DeliveryDate").getValue().toString();
                state = dataSnapshot.child("Orders").child(oid).child("State").getValue().toString();
                usoddates = dataSnapshot.child("Orders").child(oid).child("Orderdate").getValue().toString();
                adds = dataSnapshot.child("Orders").child(oid).child("Street").getValue().toString();
                lms=dataSnapshot.child("Orders").child(oid).child("LandMarg").getValue().toString();
                cys=dataSnapshot.child("Orders").child(oid).child("City").getValue().toString();
                pincds=dataSnapshot.child("Orders").child(oid).child("PinCode").getValue().toString();
                odshippings=dataSnapshot.child("Orders").child(oid).child("Shipping").getValue().toString();
                tots=dataSnapshot.child("Orders").child(oid).child("TotalPrice").getValue().toString();
                cashbks=dataSnapshot.child("Orders").child(oid).child("Cashback").getValue().toString();
                usodtimes=dataSnapshot.child("Orders").child(oid).child("Ordertime").getValue().toString();
                odsts= dataSnapshot.child("Orders").child(oid).child("orderstatus").getValue().toString();
                pymentmd = dataSnapshot.child("Orders").child(oid).child("paymentmode").getValue().toString();
                //setting text data
                usoddate.setText(dataSnapshot.child("Orders").child(oid).child("Orderdate").getValue().toString());
                usodtime.setText(" - "+dataSnapshot.child("Orders").child(oid).child("Ordertime").getValue().toString());
                usrname.setText("Delivery to : "+dataSnapshot.child("Profile").child("UserName").getValue().toString());
                add.setText(dataSnapshot.child("Orders").child(oid).child("Street").getValue().toString());
                lm.setText(dataSnapshot.child("Orders").child(oid).child("LandMarg").getValue().toString());
                cy.setText(dataSnapshot.child("Orders").child(oid).child("City").getValue().toString());
                pincd.setText(" - "+dataSnapshot.child("Orders").child(oid).child("PinCode").getValue().toString());
                usrmobno.setText("Mobile No : "+dataSnapshot.child("Profile").child("PhoneNumber").getValue().toString());
                odpri.setText(dataSnapshot.child("Orders").child(oid).child("TotalPrice").getValue().toString());
                odshipping.setText(dataSnapshot.child("Orders").child(oid).child("Shipping").getValue().toString());
                tot.setText(dataSnapshot.child("Orders").child(oid).child("TotalPrice").getValue().toString());
                cashbk.setText(dataSnapshot.child("Orders").child(oid).child("Cashback").getValue().toString());
                odst.setText(dataSnapshot.child("Orders").child(oid).child("orderstatus").getValue().toString());
                pymd.setText("Payment Mode "+dataSnapshot.child("Orders").child(oid).child("paymentmode").getValue().toString());
                deldt.setText(dataSnapshot.child("Orders").child(oid).child("DeliveryDate").getValue().toString());
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    //onstrat activity
    @Override
    protected void onStart() {
        super.onStart();
        dref.child("User").child(uid).child("Orders").child(oid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                {}
                else {
                    finish();
                }
                if(dataSnapshot.child("orderstatus").getValue().toString().equals("Delivered"))
                {
                    odcancel.setVisibility(odcancel.GONE);
                    retod.setVisibility(retod.VISIBLE);
                }
                else if(dataSnapshot.child("orderstatus").getValue().toString().equals("Confirm"))
                {
                    odcancel.setVisibility(odcancel.VISIBLE);
                    retod.setVisibility(retod.GONE);
                }
                else
                {
                    odcancel.setVisibility(odcancel.GONE);
                    retod.setVisibility(retod.GONE);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    private void getuseroddet() {
                        FirebaseRecyclerOptions<userorderlistdetailsdata> optioncart = new FirebaseRecyclerOptions
                                .Builder<userorderlistdetailsdata>()
                                .setQuery(dref.child("Orders").child(uid).child(oid), userorderlistdetailsdata.class).build();
                        FirebaseRecyclerAdapter<userorderlistdetailsdata, userorderlistdetailsviewholder> adapter = new
                                FirebaseRecyclerAdapter<userorderlistdetailsdata, userorderlistdetailsviewholder>(optioncart) {
                                    @Override
                                    protected void onBindViewHolder(@NonNull final userorderlistdetailsviewholder userorderlistdetailsviewholder,
                                                     final int i, @NonNull final userorderlistdetailsdata userorderlistdetailsdata) {
                                        //getting value from database
                                        userorderlistdetailsviewholder.id.setText("Product Id : "+userorderlistdetailsdata.getProid());
                                        userorderlistdetailsviewholder.qt.setText("Quantity : "+userorderlistdetailsdata.getQuantity());
                                        userorderlistdetailsviewholder.nm.setText("Product Name : "+userorderlistdetailsdata.getProname());
                                        userorderlistdetailsviewholder.pr.setText("Price : " + userorderlistdetailsdata.getDisprice() + " Rs/- प्रत्येक के लिए !!");
                                        Picasso.get().load(userorderlistdetailsdata.getProimage()).into(userorderlistdetailsviewholder.proim);
                                        //total based on items
                                        Integer totalprice = Integer.parseInt(userorderlistdetailsdata.getDisprice()) *
                                                Integer.parseInt(userorderlistdetailsdata.getQuantity());
                                        userorderlistdetailsviewholder.tot.setText("Total : "+totalprice+" Rs/-");
                                        //onclick
                                        userorderlistdetailsviewholder.itemView.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                // custom dialog
                                                dialog = new Dialog(userorderlistdetails.this);
                                                dialog.setContentView(R.layout.userorderlistproductdetails);
                                                dialog.setCanceledOnTouchOutside(false);
                                                dialog.setCancelable(false);
                                                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                                                // set the custom dialog components - text, image and button
                                                pid = dialog.findViewById(R.id.proid);
                                                disp = dialog.findViewById(R.id.dispached);
                                                odshipped = dialog.findViewById(R.id.ordershipped);
                                                outdilv = dialog.findViewById(R.id.outdelivery);
                                                deliveredpro = dialog.findViewById(R.id.Delivered);
                                                proofpri = dialog.findViewById(R.id.offprice);
                                                proim=dialog.findViewById(R.id.proimage);
                                                sold=dialog.findViewById(R.id.soldby);
                                                pid.setText("Product ID : "+userorderlistdetailsdata.getProid());
                                                disp.setText("Product Dispached : "+userorderlistdetailsdata.getDispached());
                                                odshipped.setText("Product Shipped : "+userorderlistdetailsdata.getOrdershipped());
                                                outdilv.setText("Product Out for Delivery : "+userorderlistdetailsdata.getOutdelivery());
                                                deliveredpro.setText("Product Delivered : "+userorderlistdetailsdata.getDelivered());
                                                proofpri.setText("Product Original Price : "+userorderlistdetailsdata.getOgprice());
                                                sold.setText("Sold By : "+userorderlistdetailsdata.getSoldby());
                                                Picasso.get().load(""+userorderlistdetailsdata.getProimage()).into(proim);
                                                WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
                                                lp.copyFrom(dialog.getWindow().getAttributes());
                                                lp.width = WindowManager.LayoutParams.MATCH_PARENT;
                                                lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                                                lp.gravity = Gravity.CENTER;
                                                dialog.getWindow().setAttributes(lp);
                                                Button dialogButton = (Button) dialog.findViewById(R.id.ok);
                                                Button can = dialog.findViewById(R.id.canc);
                                                can.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View v) {
                                                        dialog.dismiss();
                                                    }
                                                });
                                                dialog.show();
                                            }
                                        });
                                    }
                                    @NonNull
                                    @Override
                                    public userorderlistdetailsviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                                        View view = LayoutInflater.from(parent.getContext()).inflate
                                                (R.layout.userorderlistdetailsdata, parent, false);
                                        userorderlistdetailsviewholder holder = new userorderlistdetailsviewholder(view);
                                        return holder;
                                    }};
                        recyclerView.setAdapter(adapter);
                        adapter.startListening();
                     }
    //toast setup
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }}