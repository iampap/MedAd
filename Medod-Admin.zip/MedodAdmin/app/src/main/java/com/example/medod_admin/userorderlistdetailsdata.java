package com.example.medod_admin;

public class userorderlistdetailsdata {
    //string for values extracted from database
    private String proid,proimage,proname,quantity,category,disprice,ogprice,Delivered,soldby,outdelivery,ordershipped,dispached;
    //default constructor
    public userorderlistdetailsdata() {
    }
    //constructor
    public userorderlistdetailsdata(String proid, String proimage, String proname, String quantity, String category,
    String disprice, String ogprice, String delivered, String soldby, String outdelivery, String ordershipped,
    String dispached) {
        this.proid = proid;
        this.proimage = proimage;
        this.proname = proname;
        this.quantity = quantity;
        this.category = category;
        this.disprice = disprice;
        this.ogprice = ogprice;
        Delivered = delivered;
        this.soldby = soldby;
        this.outdelivery = outdelivery;
        this.ordershipped = ordershipped;
        this.dispached = dispached;
    }
    //getter and setter
    public String getSoldby() {
        return soldby;
    }
    public void setSoldby(String soldby) {
        this.soldby = soldby;
    }
    public String getDispached() {
        return dispached;
    }
    public void setDispached(String dispached) {
        this.dispached = dispached;
    }
    public String getDelivered() {
        return Delivered;
    }
    public void setDelivered(String delivered) {
        Delivered = delivered;
    }
    public String getOutdelivery() {
        return outdelivery;
    }
    public void setOutdelivery(String outdelivery) {
        this.outdelivery = outdelivery;
    }
    public String getOrdershipped() {
        return ordershipped;
    }
    public void setOrdershipped(String ordershipped) {
        this.ordershipped = ordershipped;
    }
    public String getProid() {
        return proid;
    }
    public void setProid(String proid) {
        this.proid = proid;
    }
    public String getProimage() {
        return proimage;
    }
    public void setProimage(String proimage) {
        this.proimage = proimage;
    }
    public String getProname() {
        return proname;
    }
    public void setProname(String proname) {
        this.proname = proname;
    }
    public String getQuantity() {
        return quantity;
    }
    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }
    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    public String getDisprice() {
        return disprice;
    }
    public void setDisprice(String disprice) {
        this.disprice = disprice;
    }
    public String getOgprice() {
        return ogprice;
    }
    public void setOgprice(String ogprice) {
        this.ogprice = ogprice;
    }
}