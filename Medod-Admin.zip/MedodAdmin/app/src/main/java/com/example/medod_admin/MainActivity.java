package com.example.medod_admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {
/*    //database
    private DatabaseReference references;
    private FirebaseAuth mauth;
    private FirebaseUser fuser;*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//bottom button in home page
        BottomNavigationView navView = findViewById(R.id.nav_view);
        navView.setOnNavigationItemSelectedListener(this);
        //on click on the above button provide the folling display activity
        loadfragment(new home());
    }
    //for loading the display
    public boolean loadfragment(Fragment fragment)
    {
        if(fragment != null)
        {
            getSupportFragmentManager().beginTransaction().replace(R.id.nav_host_fragment,fragment).commit();
            return true;
        }
        return false;
    }
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        Fragment fragment = null;
        switch (menuItem.getItemId())
        {
            case R.id.navigation_home:
                fragment = new home();
                break;
            case R.id.navigation_userdetails:
                fragment = new userdetails();
                break;
            case R.id.navigation_adminacc:
                fragment = new adminacc();
                break;
            case R.id.navigation_userorder:
                fragment = new userorder();
                break;
            case R.id.navigation_product:
                fragment = new product();
                break;
        }
        return loadfragment(fragment);
    }
}
























    /* // Manually configure Firebase Options. The following fields are REQUIRED:
//   - Project ID
//   - App ID
//   - API Key
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setProjectId("medodd-d2fcc")
                .setApplicationId("1:468581190085:android:f71679ff61d4ba646c63ac")
                .setDatabaseUrl("https://medodd-d2fcc.firebaseio.com")
                .setApiKey("AIzaSyAHd4zBKhb8CGgURNi9l8UWtFn1YZb1ttc")
                // setDatabaseURL(...)
                // setStorageBucket(...)
                .build();


        boolean hasBeenInitialized = false;
        List<FirebaseApp> fbsLcl = FirebaseApp.getApps(this);
        for (FirebaseApp app : fbsLcl) {
            if (app.getName().equals("Medod")) {
                hasBeenInitialized = true;
            }
            if (!hasBeenInitialized) {
                FirebaseApp.initializeApp(getApplicationContext(), options, "Medod");
            } else {
                FirebaseApp.getInstance("Medod");
            }
            FirebaseApp ap = FirebaseApp.getInstance("Medod");
            FirebaseDatabase secondaryDatabase = FirebaseDatabase.getInstance(ap);
*//*
            HashMap<String, String> map = new HashMap<>();
            map.put("UserName", "hii");
            secondaryDatabase.getReference().child("hello").setValue(map);*//*

            references = secondaryDatabase.getReference().child("products").child("Sanitizer").child(" 29:Mar:2020 23:03:46:pm");
            references.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Toast.makeText(getApplicationContext(), dataSnapshot.child("price").getValue().toString(), Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
   */