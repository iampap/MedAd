package com.example.medod_admin;

import android.view.View;

public interface itemclicklistner {
    void onClick(View view, int position, boolean isLongClick);
}
