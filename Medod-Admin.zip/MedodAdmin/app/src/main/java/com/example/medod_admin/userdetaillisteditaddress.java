package com.example.medod_admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.List;

public class userdetaillisteditaddress extends AppCompatActivity {
    //binding
    private TextView hn,lm,cy,st,pc,id;
    private Button upaddr;
    private String addrid,str,la,cit,sta,pin,userid;
    //firebase
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    //toast
    private Toast toast;
    //alertdialoge
    private AlertDialog alertDialog;
    //another database
    private FirebaseDatabase secondaryDatabase;
    private DatabaseReference dref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userdetaillisteditaddress);
    //binding
    hn = findViewById(R.id.text_houseno);
    lm = findViewById(R.id.text_landmarg);
    cy = findViewById(R.id.text_city);
    st = findViewById(R.id.text_state);
    pc = findViewById(R.id.text_pincode);
    id=findViewById(R.id.addr_id);
    upaddr = findViewById(R.id.button_addaddr);
        //secondary database
        //getting details from another database
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setProjectId("medodd-d2fcc")
                .setApplicationId("1:468581190085:android:f71679ff61d4ba646c63ac")
                .setDatabaseUrl("https://medodd-d2fcc.firebaseio.com")
                .setApiKey("AIzaSyAHd4zBKhb8CGgURNi9l8UWtFn1YZb1ttc")
                // setDatabaseURL(...)
                // setStorageBucket(...)
                .build();
        boolean hasBeenInitialized = false;
        List<FirebaseApp> fbsLcl = FirebaseApp.getApps(getApplicationContext());
        for (FirebaseApp app : fbsLcl) {
            if (app.getName().equals("Medod")) {
                hasBeenInitialized = true;
            }
            if (!hasBeenInitialized) {
                FirebaseApp.initializeApp(getApplicationContext(), options, "Medod");
            } else {
                FirebaseApp.getInstance("Medod");
            }
            FirebaseApp ap = FirebaseApp.getInstance("Medod");
            secondaryDatabase = FirebaseDatabase.getInstance(ap);
        }
    //firebase
    mauth = FirebaseAuth.getInstance();
    fuser = mauth.getCurrentUser();
    dref = secondaryDatabase.getReference();
    //getintent
    addrid=getIntent().getExtras().get("addreddid").toString();
    userid=getIntent().getExtras().get("userid").toString();
    str=getIntent().getExtras().get("address").toString();
    la=getIntent().getExtras().get("landmarg").toString();
    cit=getIntent().getExtras().get("city").toString();
    sta=getIntent().getExtras().get("state").toString();
    pin=getIntent().getExtras().get("pincode").toString();
    //settext
        id.setText("Address ID: "+addrid.toString());
        hn.setText(str);
        lm.setText(la);
        cy.setText(cit);
        st.setText(sta);
        pc.setText(pin);
    //click
        upaddr.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(hn.getText().toString().trim().equals(str) && lm.getText().toString().trim().equals(la) &&
                    cy.getText().toString().trim().equals(cit) && st.getText().toString().trim().equals(sta) &&
                    pc.getText().toString().trim().equals(pin))
            {
                toast = Toast.makeText(getApplicationContext(),"Address Exist (कृपया पता अपडेट करें)!!",Toast.LENGTH_SHORT);
                toast();
            }
            else {
                updateaddr();
            }
        }
    });
}
    //updating address
    private void updateaddr() {
        final String street = hn.getText().toString().trim();
        final String land = lm.getText().toString().trim();
        final String ci = cy.getText().toString().trim();
        final String stat = st.getText().toString().trim();
        final String pi= pc.getText().toString().trim();
        if (street.isEmpty()) {
            hn.setError("Address please..");
            hn.requestFocus();
            return;
        }
        else if (land.isEmpty()) {
            lm.setError("LandMarg please..");
            lm.requestFocus();
            return;
        }
        else if (ci.isEmpty()) {
            cy.setError("City please..");
            cy.requestFocus();
            return;
        }
        else if (stat.isEmpty()) {
            st.setError("State please..");
            st.requestFocus();
            return;
        }
        else if (pi.isEmpty()) {
            pc.setError("PinCode please..");
            pc.requestFocus();
            return;
        }
        else{
            //alert
            AlertDialog.Builder dialog = new AlertDialog.Builder(this);
            dialog.setTitle("Updating (कृपया रुकिये)");
            dialog.setMessage("Hang On, Updating your Address!!");
            dialog.setCancelable(false);
            alertDialog = dialog.create();
            alertDialog.show();
            //updating address
            HashMap<String, String> map = new HashMap<>();
            map.put("Street", street);
            map.put("LandMarg", land);
            map.put("City", ci);
            map.put("State", stat);
            map.put("PinCode", pi);
            map.put("Addressid", addrid);
            dref.child("User").child(userid).child("Address").child(addrid).setValue(map).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    alertDialog.dismiss();
                    toast = Toast.makeText(getApplicationContext(),"Address Updated!!",Toast.LENGTH_SHORT);
                    toast();
                    finish();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    alertDialog.dismiss();
                    toast = Toast.makeText(getApplicationContext(),"Not Updated!!",Toast.LENGTH_SHORT);
                    toast();
                }
            });
        }
    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}

