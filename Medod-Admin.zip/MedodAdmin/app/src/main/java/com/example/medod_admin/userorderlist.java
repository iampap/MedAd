package com.example.medod_admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class userorderlist extends AppCompatActivity {
    //binding
    private TextView email;
    //recycler
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    //firebase
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    private DatabaseReference dref;
    //another database
    FirebaseDatabase secondaryDatabase;
    //toast
    private Toast toast;
    //string contain current user
    private String user,uid,uname,uemail;
    //image refresh
    private ImageView refrs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userorderlist);
        //binding
        email=findViewById(R.id.orderuseremail);
        //get intent
        uid=getIntent().getStringExtra("userid");
        uname=getIntent().getStringExtra("username");
        uemail=getIntent().getStringExtra("useremail");
        //set email
        email.setText("User-Email : "+uemail.toString());
        //refresh
        refrs = findViewById(R.id.refreshusodlist);
        refrs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Reload current fragment
                Intent intent = getIntent();
                finish();
                overridePendingTransition(0, 0);
                startActivity(intent);
                overridePendingTransition(0, 0);
            }
        });
        //recycler
        recyclerView = findViewById(R.id.userorderlistrecycler);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        //firebase
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        user = fuser.getUid();
        //getting details from another database
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setProjectId("medodd-d2fcc")
                .setApplicationId("1:468581190085:android:f71679ff61d4ba646c63ac")
                .setDatabaseUrl("https://medodd-d2fcc.firebaseio.com")
                .setApiKey("AIzaSyAHd4zBKhb8CGgURNi9l8UWtFn1YZb1ttc")
                // setDatabaseURL(...)
                // setStorageBucket(...)
                .build();
        boolean hasBeenInitialized = false;
        List<FirebaseApp> fbsLcl = FirebaseApp.getApps(getApplicationContext());
        for (FirebaseApp app : fbsLcl) {
            if (app.getName().equals("Medod")) {
                hasBeenInitialized = true;
            }
            if (!hasBeenInitialized) {
                FirebaseApp.initializeApp(getApplicationContext(), options, "Medod");
            } else {
                FirebaseApp.getInstance("Medod");
            }}
        FirebaseApp ap = FirebaseApp.getInstance("Medod");
        secondaryDatabase = FirebaseDatabase.getInstance(ap);
        dref = secondaryDatabase.getReference();
        //getuserdetails
        getuseroddet();
    }

    @Override
    protected void onStart() {
        super.onStart();
        dref.child("Orders").child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                {}
                else {
                    finish();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void getuseroddet() {
        final ArrayList<String> pidlist = new ArrayList<String>();
        final List<userorderlistdata> odstatus = new ArrayList<>();
        dref.child("User").child(uid).child("Orders").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull final DataSnapshot dataSnapshot) {
                for (final DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    userorderlistdata odlst = postSnapshot.getValue(userorderlistdata.class);
                    String user = postSnapshot.getKey().toString();
                    long count = dataSnapshot.getChildrenCount();
                    pidlist.add(user);
                    odstatus.add(odlst);
                    for (int i = 0; i < pidlist.size(); i++) {
                        FirebaseRecyclerOptions<userorderlistdata> optioncart = new FirebaseRecyclerOptions.Builder<userorderlistdata>()
                                .setQuery(dref.child("Orders").child(uid), userorderlistdata.class).build();
                        FirebaseRecyclerAdapter<userorderlistdata, userorderlistviewholder> adapter = new
                                FirebaseRecyclerAdapter<userorderlistdata, userorderlistviewholder>(optioncart) {
                            @Override
                            protected void onBindViewHolder(@NonNull final userorderlistviewholder userorderlistviewholder, final int i,
                                                            @NonNull final userorderlistdata userorderlistdata) {
                                dref.child("Orders").child(uid).child(pidlist.get(i)).addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        userorderlistviewholder.odsta.setText("Order Status : "+odstatus.get(i).getOrderstatus());
                                        userorderlistviewholder.procount.setText(dataSnapshot.getChildrenCount()+" Product Ordered");
                                        userorderlistviewholder.odid.setText("Order ID : " + pidlist.get(i).toString());
                                        userorderlistviewholder.itemView.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                Intent in = new Intent(getApplicationContext(), userorderlistdetails.class);
                                                in.putExtra("orderid",pidlist.get(i).toString());
                                                in.putExtra("userid",uid);
                                                in.putExtra("username",uname);
                                                in.putExtra("useremail",uemail);
                                                startActivity(in);
                                            }
                                        });
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {
                                        Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
                                    }
                                });
                            }
                            @NonNull
                            @Override
                            public userorderlistviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.userorderlistdata, parent,
                                        false);
                                userorderlistviewholder holder = new userorderlistviewholder(view);
                                return holder;
                            }};
                        recyclerView.setAdapter(adapter);
                        adapter.startListening();
                    }}}
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }}); }
    //toast setup
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }}