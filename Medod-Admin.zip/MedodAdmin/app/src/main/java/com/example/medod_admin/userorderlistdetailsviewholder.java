package com.example.medod_admin;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class userorderlistdetailsviewholder extends RecyclerView.ViewHolder implements View.OnClickListener {
    TextView id,qt,nm,pr,tot;
    ImageView proim;
    public itemclicklistner userorderprodetails;
    public userorderlistdetailsviewholder(@NonNull View itemView) {
        super(itemView);
        id = itemView.findViewById(R.id.proid);
        qt = itemView.findViewById(R.id.quantity);
        nm = itemView.findViewById(R.id.itname);
        pr = itemView.findViewById(R.id.itprice);
        tot = itemView.findViewById(R.id.ittot);
        proim = itemView.findViewById(R.id.itimage);
    }
    @Override
    public void onClick(View v) {
    }
    public void setUserorderprodetails(itemclicklistner userorderprodetails) {
        this.userorderprodetails = userorderprodetails;
    }
}
