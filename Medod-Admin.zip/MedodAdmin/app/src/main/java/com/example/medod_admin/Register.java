package com.example.medod_admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class Register extends AppCompatActivity {
    //binding
    EditText edemail,edpass,name,phone;
    String userID;
    //firebase
    private FirebaseAuth mAuth;
    private FirebaseDatabase database;
    private DatabaseReference reff;
    private FirebaseUser firebaseUser;
    //toast
    private Toast toast;
    //alert
    private AlertDialog alertDialog;
   /* @Override
    protected void onStart() {
        super.onStart();
        if (firebaseUser != null) {
            Intent in = new Intent(Register.this, MainActivity.class);
            startActivity(in);
            finish();
        }
    }*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        //binding
        edemail= (EditText)findViewById(R.id.text_email);
        edpass = (EditText)findViewById(R.id.edit_text_password);
        name = (EditText)findViewById(R.id.text_name);
        phone=(EditText)findViewById(R.id.phone_number);
        //firebase
        mAuth = FirebaseAuth.getInstance();
        firebaseUser = mAuth.getCurrentUser();
        database=FirebaseDatabase.getInstance();
        reff= database.getReference();
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        Button btnsignup = (Button)findViewById(R.id.button_sign_up);
        btnsignup.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                registeruser();
            }
        });
    }
    //register user validation
    private void registeruser() {
        final String email = edemail.getText().toString().trim();
        String password = edpass.getText().toString().trim();
        final String usname = name.getText().toString().trim();
        final String mobno=phone.getText().toString().trim();
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        if (email.isEmpty()) {
            edemail.setError("Email please..");
            edemail.requestFocus();
            return;
        } else {
            if (!email.matches(emailPattern)) {
                edemail.setError("Invalid Email");
                edemail.requestFocus();
                return;
            }}
        if (password.isEmpty()) {
            edpass.setError("Password please..");
            edpass.requestFocus();
            return;
        }
        if (password.length() < 6) {
            edpass.setError("More than 6");
            edpass.requestFocus();
            return;
        }
        //creating account in the database
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Register Account");
        dialog.setMessage("Hang On!!");
        dialog.setCancelable(false);
        alertDialog = dialog.create();
        alertDialog.show();
        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                alertDialog.dismiss();
                if(task.isSuccessful()){
                    FirebaseUser user = mAuth.getCurrentUser();
                    userID = user.getUid();
                    HashMap<String, String> map = new HashMap<>();
                    map.put("UserName", usname);
                    map.put("UserEmail", email);
                    map.put("PhoneNumber", mobno);
                    reff.child("Admin").child(userID).child("Profile").setValue(map);
                    toast=Toast.makeText(getApplicationContext(),"Registration Successful!!",Toast.LENGTH_SHORT);
                    toast();
                        Intent in = new Intent(Register.this, MainActivity.class);
                        startActivity(in);
                        finish();
                }
                else{
                    toast=Toast.makeText(getApplicationContext(),task.getException().getMessage(),Toast.LENGTH_SHORT);
                    toast();
                }
            }
        });
    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
    }
