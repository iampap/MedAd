package com.example.medod_admin;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class productlist extends AppCompatActivity {
    //binding
    private Button addprod;
    private String currenttime, currentdate, productid,productname,itemkey,imgurl;
    private EditText proname,pri,desc,etogproprice,etprooverview,etprodingredients,etprodosage,etprolife,
            etpronetquantity,etprobrandabout,etprocaution,etproinfo,etprocertification;
    private TextView prodname,delete;
    //for image getting from user and upload in databse
    private static final int gallpic = 1;
    private Uri imguri;
    //recycler
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    //firebase
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    private DatabaseReference ref;
    //another database
    private FirebaseDatabase secondaryDatabase;
    private StorageReference storageReference;
    //toast
    private Toast toast;
    //string contain current user
    private String user;
    //refresh
    private ImageView refreshproduct,proim;
    //dialog
    private Dialog dialog;
    //progress bar
    private ProgressDialog bar;
    @Override
    protected void onStart() {
        super.onStart();
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.child("products").child(productname).exists())
                {
                    long no = dataSnapshot.child("products").child(productname).getChildrenCount();
                }
                else {
                    finish();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(),databaseError.getMessage(),Toast.LENGTH_LONG).show();
            }});
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productlist);
        //getting intent
        productname = getIntent().getStringExtra("productname");
        //binding
        prodname = findViewById(R.id.proname);
        delete = findViewById(R.id.del);
        addprod = findViewById(R.id.additem);
        prodname.setText("Items Available in "+productname);
        addprod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                customdialog();
            }
        });
        //brefresh
        refreshproduct = findViewById(R.id.refreshitem);
        refreshproduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Reload current fragment
                Intent intent = getIntent();
                finish();
                overridePendingTransition(0, 0);
                startActivity(intent);
                overridePendingTransition(0, 0);
            }
        });
        //progressbar
        bar = new ProgressDialog(this);
        //recycler
        recyclerView = findViewById(R.id.itemrecycler);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        //firebase
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        user = fuser.getUid();
        //getting details from another database
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setProjectId("medodd-d2fcc")
                .setApplicationId("1:468581190085:android:f71679ff61d4ba646c63ac")
                .setDatabaseUrl("https://medodd-d2fcc.firebaseio.com")
                .setApiKey("AIzaSyAHd4zBKhb8CGgURNi9l8UWtFn1YZb1ttc")
                // setDatabaseURL(...)
                // setStorageBucket(...)
                .build();
        boolean hasBeenInitialized = false;
        List<FirebaseApp> fbsLcl = FirebaseApp.getApps(getApplicationContext());
        for (FirebaseApp app : fbsLcl) {
            if (app.getName().equals("Medod")) {
                hasBeenInitialized = true;
            }
            if (!hasBeenInitialized) {
                FirebaseApp.initializeApp(getApplicationContext(), options, "Medod");
            } else {
                FirebaseApp.getInstance("Medod");
            }
        }
        FirebaseApp ap = FirebaseApp.getInstance("Medod");
        secondaryDatabase = FirebaseDatabase.getInstance(ap);
        ref = secondaryDatabase.getReference();
        storageReference = FirebaseStorage.getInstance().getReference().child("Product Images");
        //delete
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(productlist.this);
                dialog.setTitle("Are You Sure!!");
                dialog.setMessage("Deleting this Item!!");
                dialog.setCancelable(false);
                dialog.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ref.child("products").child(productname).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                             if(task.isSuccessful())
                             {
                                 finish();
                                 toast=Toast.makeText(getApplicationContext(),"Deleted Successfully..",Toast.LENGTH_SHORT);
                                 toast.show();
                             }
                            }
                        });
                    }
                });
                dialog.setNegativeButton("No Please!!", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                AlertDialog alertDialog = dialog.create();
                alertDialog.show();
            }
        });
        //getting product details
        productdet();
    }
    private void customdialog() {
// custom dialog
        dialog = new Dialog(productlist.this);
        dialog.setContentView(R.layout.itemnewdisplay);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(false);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        // set the custom dialog components - text, image and button
        proname = (EditText) dialog.findViewById(R.id.proname);
        desc = dialog.findViewById(R.id.prodesc);
        pri = dialog.findViewById(R.id.proprice);
        proim = dialog.findViewById(R.id.imageitem);
        etogproprice= dialog.findViewById(R.id.ogproprice);
        etprooverview= dialog.findViewById(R.id.prooverview);
        etprodingredients= dialog.findViewById(R.id.prodingredients);
        etprodosage= dialog.findViewById(R.id.prodosage);
        etprolife= dialog.findViewById(R.id.prolife);
        etpronetquantity= dialog.findViewById(R.id.pronetquantity);
        etprobrandabout= dialog.findViewById(R.id.probrandabout);
        etprocaution= dialog.findViewById(R.id.procaution);
        etproinfo= dialog.findViewById(R.id.proinfo);
        etprocertification= dialog.findViewById(R.id.procertification);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.CENTER;
        dialog.getWindow().setAttributes(lp);
        Button dialogButton = (Button) dialog.findViewById(R.id.addbtn);
        Button can = dialog.findViewById(R.id.cancel);
        // if button is clicked, close the custom dialog
        proim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OpenGallery();
            }
        });
        dialogButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(imguri == null)
                {
                    Toast.makeText(getApplicationContext(),"Image required",Toast.LENGTH_LONG).show();
                }
                else if(proname.getText().toString().isEmpty())
                {
                    proname.setError("Please Add Name of Item!!");
                    proname.requestFocus();
                    return;
                }
                else if(desc.getText().toString().isEmpty())
                {
                    desc.setError("Please Add Description about Item!!");
                    desc.requestFocus();
                    return;
                }
                else if(pri.getText().toString().isEmpty())
                {
                    pri.setError("Please Add Originl Price of Item!!");
                    pri.requestFocus();
                    return;
                }
                else if(etogproprice.getText().toString().isEmpty())
                {
                    etogproprice.setError("Please Add Discounted Price of Item!!");
                    etogproprice.requestFocus();
                    return;
                }
                else if(etprooverview.getText().toString().isEmpty())
                {
                    etprooverview.setError("Please Add OverView about Item!!");
                    etprooverview.requestFocus();
                    return;
                }
                else if(etprodingredients.getText().toString().isEmpty())
                {
                    etprodingredients.setError("Please Add Ingredients of Item!!");
                    etprodingredients.requestFocus();
                    return;
                }
                else if(etprodosage.getText().toString().isEmpty())
                {
                    etprodosage.setError("Please Add Dosage of Item!!");
                    etprodosage.requestFocus();
                    return;
                }
                else if(etprolife.getText().toString().isEmpty())
                {
                    etprolife.setError("Please Add Life of Item (Valid Till)!!");
                    etprolife.requestFocus();
                    return;
                }
                else if(etpronetquantity.getText().toString().isEmpty())
                {
                    etpronetquantity.setError("Please Add Net Quantity of Item!!");
                    etpronetquantity.requestFocus();
                    return;
                }
                else if(etprobrandabout.getText().toString().isEmpty())
                {
                    etprobrandabout.setError("Please Add About Brand Information!!");
                    etprobrandabout.requestFocus();
                    return;
                }
                else if(etprocaution.getText().toString().isEmpty())
                {
                    etprocaution.setError("Please Add Product Caution!!");
                    etprocaution.requestFocus();
                    return;
                }
                else if(etproinfo.getText().toString().isEmpty())
                {
                    etproinfo.setError("Please Add Information of Item!!");
                    etproinfo.requestFocus();
                    return;
                }
                else if(etprocertification.getText().toString().isEmpty())
                {
                    etprocertification.setError("Please Add Product Certification!!");
                    etprocertification.requestFocus();
                    return;
                }
                else {
                    storeitemsinformation();
                }
            }
        });
        can.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }
    //adding the image to storage database
    private void storeitemsinformation() {
        bar.setTitle("Adding New Items");
        bar.setMessage("Plz Wait....while we r adding the items!");
        bar.setCanceledOnTouchOutside(false);
        bar.setCancelable(false);
        bar.show();
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat currdate= new SimpleDateFormat(" dd:MMM:yyyy");
        currentdate = currdate.format(calendar.getTime());
        SimpleDateFormat currtime= new SimpleDateFormat("HH:MM:SS:a");
        currenttime = currtime.format(calendar.getTime());
        itemkey =  currentdate+" "+currenttime;
        final StorageReference filepath = storageReference.child(imguri.getEncodedPath()+":"+itemkey+".jpg");
        final UploadTask uploadTask = filepath.putFile(imguri);
        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                String mess = e.toString();
                Toast.makeText(getApplicationContext(),"Error" + mess,Toast.LENGTH_LONG);
                bar.dismiss();
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                toast=Toast.makeText(getApplicationContext(),"Image Upload Successfully..",Toast.LENGTH_SHORT);
                toast.show();
                Task<Uri> uriTask = uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                    @Override
                    public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                        if(!task.isSuccessful())
                        {
                            throw task.getException();
                        }
                        imgurl = filepath.getDownloadUrl().toString();
                        return filepath.getDownloadUrl();
                    }
                }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                    @Override
                    public void onComplete(@NonNull Task<Uri> task) {
                        if(task.isSuccessful())
                        {
                            imgurl = task.getResult().toString();
                            addproduct();
                        }
                    }
                });
            }
        });
    }
    private void addproduct() {
        Calendar calfordate = Calendar.getInstance();
        //timestamp
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("ddMMyyyyhhmmss");
        String tss = simpleDateFormat.format(calfordate.getTime());
        try {
            final Date date = simpleDateFormat.parse(tss);
            long ts = date.getTime();
            productid = String.valueOf(ts);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        HashMap<String , Object> promap = new HashMap<>();
        promap.put("pid",productid);
        promap.put("date",currentdate);
        promap.put("time",currenttime);
        promap.put("description",desc.getText().toString());
        promap.put("image",imgurl);
        promap.put("category",productname);
        promap.put("disprice",pri.getText().toString());
        promap.put("proname",proname.getText().toString());
        promap.put("ogprice",etogproprice.getText().toString());
        promap.put("prooverview",etprooverview.getText().toString());
        promap.put("proingredients",etprodingredients.getText().toString());
        promap.put("prodosage",etprodosage.getText().toString());
        promap.put("prolife",etprolife.getText().toString());
        promap.put("pronetquantity",etpronetquantity.getText().toString());
        promap.put("probrandabout",etprobrandabout.getText().toString());
        promap.put("procaution",etprocaution.getText().toString());
        promap.put("proinfo",etproinfo.getText().toString());
        promap.put("procertification",etprocertification.getText().toString());
        ref.child("products").child(productname).child(productid).setValue(promap).
                addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            bar.dismiss();
                            dialog.dismiss();
                            toast = Toast.makeText(getApplicationContext(), "Item Added!!", Toast.LENGTH_SHORT);
                            toast.show();
                            // Reload current fragment
                            Intent intent = getIntent();
                            finish();
                            overridePendingTransition(0, 0);
                            startActivity(intent);
                            overridePendingTransition(0, 0);
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                bar.dismiss();
                dialog.dismiss();
                toast = Toast.makeText(getApplicationContext(), "Item Not Added!!", Toast.LENGTH_SHORT);
                toast.show();
                // Reload current fragment
                Intent intent = getIntent();
                finish();
                overridePendingTransition(0, 0);
                startActivity(intent);
                overridePendingTransition(0, 0);
            }
        });
    }
    private void productdet() {
                        FirebaseRecyclerOptions<productlistdata> optioncart = new FirebaseRecyclerOptions.Builder<productlistdata>()
                                .setQuery(ref.child("products").child(productname), productlistdata.class).build();
                        FirebaseRecyclerAdapter<productlistdata, productlistviewholder>
                                adapter = new FirebaseRecyclerAdapter<productlistdata, productlistviewholder>(optioncart) {
                            @Override
                            protected void onBindViewHolder(@NonNull final productlistviewholder productlistviewholder,
                                                            final int i,
                                                            @NonNull final productlistdata productlistdata) {
                                productlistviewholder.itemname.setText("ID : " + productlistdata.getPid());
                                final String id = productlistdata.getPid();
                                productlistviewholder.itemView.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v){
                                        Intent in = new Intent(productlist.this, productlistdetails.class);
                                        in.putExtra("pid",productlistdata.getPid());
                                        in.putExtra("date",productlistdata.getDate());
                                        in.putExtra("time",productlistdata.getTime());
                                        in.putExtra("description",productlistdata.getDescription());
                                        in.putExtra("image",productlistdata.getImage());
                                        in.putExtra("category",productlistdata.getCategory());
                                        in.putExtra("disprice",productlistdata.getDisprice());
                                        in.putExtra("proname",productlistdata.getProname());
                                        in.putExtra("ogprice",productlistdata.getOgprice());
                                        in.putExtra("prooverview",productlistdata.getProoverview());
                                        in.putExtra("proingredients",productlistdata.getProingredients());
                                        in.putExtra("prodosage",productlistdata.getProdosage());
                                        in.putExtra("prolife",productlistdata.getProlife());
                                        in.putExtra("pronetquantity",productlistdata.getPronetquantity());
                                        in.putExtra("probrandabout",productlistdata.getProbrandabout());
                                        in.putExtra("procaution",productlistdata.getProcaution());
                                        in.putExtra("proinfo",productlistdata.getProinfo());
                                        in.putExtra("procertification",productlistdata.getProcertification());
                                        startActivity(in);
                                    }
                                });
                            }
                            @NonNull
                            @Override
                            public productlistviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.productlistdata, parent, false);
                                productlistviewholder holder = new productlistviewholder(view);
                                return holder;
                            }
                        };
                        recyclerView.setAdapter(adapter);
                        adapter.startListening();
    }
    //adding the image from user to display
    private void OpenGallery()
    {
        Intent in = new Intent();
        in.setAction(Intent.ACTION_GET_CONTENT);
        in.setType("image/*");
        startActivityForResult(in,gallpic);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == gallpic && resultCode == RESULT_OK && data!=null)
        {
            imguri = data.getData();
            proim.setImageURI(imguri);
        }
    }
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }
}