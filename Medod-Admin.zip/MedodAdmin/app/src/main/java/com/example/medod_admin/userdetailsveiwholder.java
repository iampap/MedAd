package com.example.medod_admin;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class userdetailsveiwholder extends RecyclerView.ViewHolder implements View.OnClickListener {
    TextView id;
    public itemclicklistner userdetailsid;
    public userdetailsveiwholder(@NonNull View itemView) {
        super(itemView);
        id=itemView.findViewById(R.id.userid);
    }
    @Override
    public void onClick(View v) {
    }
    public void setUserdetailsid(itemclicklistner userdetailsid) {
        this.userdetailsid = userdetailsid;
    }
}
