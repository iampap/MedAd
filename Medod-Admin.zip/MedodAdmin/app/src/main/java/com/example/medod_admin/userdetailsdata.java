package com.example.medod_admin;

public class userdetailsdata {
    String userid,PhoneNumber,UserEmail,UserName,id;
    public userdetailsdata() {
    }

    public userdetailsdata(String userid, String phoneNumber, String userEmail, String userName, String id) {
        this.userid = userid;
        PhoneNumber = phoneNumber;
        UserEmail = userEmail;
        UserName = userName;
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    public String getUserEmail() {
        return UserEmail;
    }

    public void setUserEmail(String userEmail) {
        UserEmail = userEmail;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }
}
