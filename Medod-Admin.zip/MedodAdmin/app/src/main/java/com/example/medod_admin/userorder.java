package com.example.medod_admin;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class userorder extends Fragment {
    //recycler
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    //firebase
    private FirebaseAuth mauth;
    private FirebaseUser fuser;
    private DatabaseReference dref;
    //another database
    FirebaseDatabase secondaryDatabase;
    //toast
    private Toast toast;
    //string contain current user
    private String user;
    //image refresh
    private ImageView refrs;
    @Override
    public View onCreateView(LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_userorder, null);
        //binding
        refrs = view.findViewById(R.id.refreshusod);
        refrs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Reload current fragment
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.nav_host_fragment,new userorder()).remove(userorder.this);
                ft.commit();
            }
        });
        //recycler
        recyclerView = view.findViewById(R.id.userorderrecycler);
        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        //firebase
        mauth = FirebaseAuth.getInstance();
        fuser = mauth.getCurrentUser();
        user = fuser.getUid();
        //getting details from another database
        FirebaseOptions options = new FirebaseOptions.Builder()
                .setProjectId("medodd-d2fcc")
                .setApplicationId("1:468581190085:android:f71679ff61d4ba646c63ac")
                .setDatabaseUrl("https://medodd-d2fcc.firebaseio.com")
                .setApiKey("AIzaSyAHd4zBKhb8CGgURNi9l8UWtFn1YZb1ttc")
                // setDatabaseURL(...)
                // setStorageBucket(...)
                .build();
        boolean hasBeenInitialized = false;
        List<FirebaseApp> fbsLcl = FirebaseApp.getApps(getContext());
        for (FirebaseApp app : fbsLcl) {
            if (app.getName().equals("Medod")) {
                hasBeenInitialized = true;
            }
            if (!hasBeenInitialized) {
                FirebaseApp.initializeApp(getContext(), options, "Medod");
            } else {
                FirebaseApp.getInstance("Medod");
            }}
        FirebaseApp ap = FirebaseApp.getInstance("Medod");
        secondaryDatabase = FirebaseDatabase.getInstance(ap);
        dref = secondaryDatabase.getReference();
        //getuserdetails
        getuserdet();
        return view;
    }
    private void getuserdet() {
        dref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.child("User").exists())
                {
                    final List<userorderdata> pidlist = new ArrayList<>();
                    dref.child("User").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull final DataSnapshot dataSnapshot) {
                            for (final DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                                userorderdata user = postSnapshot.child("Profile").getValue(userorderdata.class);
                                long count = dataSnapshot.getChildrenCount();
                                pidlist.add(user);
                                for (int i = 0; i < pidlist.size(); i++) {
                                    FirebaseRecyclerOptions<userorderdata> optioncart = new FirebaseRecyclerOptions.Builder<userorderdata>()
                                            .setQuery(dref.child("User"), userorderdata.class).build();
                                    FirebaseRecyclerAdapter<userorderdata, userorderviewholder> adapter = new FirebaseRecyclerAdapter<userorderdata, userorderviewholder>(optioncart) {
                                        @Override
                                        protected void onBindViewHolder(@NonNull final userorderviewholder userorderviewholder, final int i,
                                                                        @NonNull final userorderdata userorderdata) {
                                            dref.addListenerForSingleValueEvent(new ValueEventListener() {
                                                @Override
                                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                    userorderviewholder.count.setText("Order Placed : 0");
                                                    userorderviewholder.id.setText("User-ID : " + pidlist.get(i).getUserid());
                                                    userorderviewholder.name.setText("User-Name : " + pidlist.get(i).getUserName());
                                                    userorderviewholder.email.setText("User-Email : " + pidlist.get(i).getUserEmail());
                                                    if(dataSnapshot.child("Orders").child(pidlist.get(i).getUserid()).exists())
                                                    {
                                                        userorderviewholder.count.setText("Order Placed : "+dataSnapshot.
                                                                child("Orders").child(pidlist.get(i).getUserid()).getChildrenCount());
                                                        userorderviewholder.itemView.setOnClickListener(new View.OnClickListener() {
                                                            @Override
                                                            public void onClick(View v) {
                                                                Intent in = new Intent(getContext(), userorderlist.class);
                                                                in.putExtra("userid",pidlist.get(i).getUserid());
                                                                in.putExtra("username",pidlist.get(i).getUserName());
                                                                in.putExtra("useremail",pidlist.get(i).getUserEmail());
                                                                startActivity(in);
                                                            }
                                                        });
                                                    }
                                                }
                                                @Override
                                                public void onCancelled(@NonNull DatabaseError databaseError) {
                                                    Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
                                                }
                                            });
                                        }
                                        @NonNull
                                        @Override
                                        public userorderviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                                            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.userorderdata, parent,
                                                    false);
                                            userorderviewholder holder = new userorderviewholder(view);
                                            return holder;
                                        }};
                                    recyclerView.setAdapter(adapter);
                                    adapter.startListening();
                                }}}
                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
                        }});
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    //toast setup
    private void toast() {
        View view = toast.getView();
        //Gets the actual oval background of the Toast then sets the colour filter
        view.getBackground().setColorFilter(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        //Gets the TextView from the Toast so it can be editted
        TextView text = view.findViewById(android.R.id.message);
        text.setTextColor(Color.BLACK);
        toast.show();
    }}